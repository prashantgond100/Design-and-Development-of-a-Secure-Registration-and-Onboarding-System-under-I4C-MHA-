/* 
   NCRP FI Onboarding – Category-wise XLSX Loader
*/

document.addEventListener("DOMContentLoaded", () => {
  console.log("fi.js loaded");

  /* DOM ELEMENTS  */
  const fiCategorySelect = document.getElementById("fi_category");
  const fiSearch = document.getElementById("fi_search");
  const fiOptionsContainer = document.getElementById("fi_options");
  const fiHiddenInput = document.getElementById("fi_selector");
  const fiForm = document.getElementById("fiForm");
  const incorporationDateInput = document.getElementById("incorporation_date");
  const balanceSheetSection = document.getElementById("balanceSheetUploadSection");
  const params = new URLSearchParams(location.search);
  const isEdit = params.get("edit") === "1";

  console.log("fiForm:", fiForm);

  /*  CATEGORY XLSX MAP  */
  const categoryExcelMap = {
    "Financial Market Infrastructure": "fi_list/Financial Market Infrastructure.xlsx",
    "Retail Payments Organisation": "fi_list/Retail Payments Organisation.xlsx",
    "Central Counter Parties": "fi_list/Central Counter Parties.xlsx",
    "Interoperable Mobile and Net Banking": "fi_list/Interoperable Mobile and Net Banking.xlsx",
    "BBPS Bharat Bill Payment Central Unit BBPCU": "fi_list/BBPS Bharat Bill Payment Central Unit BBPCU.xlsx",
    "BBPS Bharat Bill Payment Operating Units BBPOUs": "fi_list/BBPS Bharat Bill Payment Operating Units BBPOUs.xlsx",
    "BBPS Cards Payment Networks": "fi_list/BBPS Cards Payment Networks.xlsx",
    "BBPS Cross border Money Transfer in bound only": "fi_list/BBPS Cross border Money Transfer in-bound only.xlsx",
    "BBPS ATM Networks": "fi_list/BBPS ATM Networks.xlsx",
    "BBPS Prepaid Payment Instruments": "fi_list/BBPS Prepaid Payment Instruments.xlsx",
    "BBPS Payment Aggregators": "fi_list/BBPS Payment Aggregators.xlsx",
    "BBPS White Label ATM Operators": "fi_list/BBPS White Label ATM Operators.xlsx"
  };
  let fiNames = [];

  /* INITIAL STATE */
  if (fiSearch) {
    fiSearch.disabled = true;
    fiSearch.value = "Select FI category first";
  }

  /*  CATEGORY CHANGE  */
  if (fiCategorySelect && fiSearch) {
    fiCategorySelect.addEventListener("change", async () => {
      const selectedCategory = fiCategorySelect.value;

      fiSearch.disabled = true;
      fiSearch.value = "Loading FIs...";
      fiOptionsContainer.innerHTML = "";
      fiHiddenInput.value = "";

      if (!categoryExcelMap[selectedCategory]) {
        fiSearch.value = "";
        fiSearch.placeholder = "-- Select FI --";
        return;
      }

      try {
        const response = await fetch(categoryExcelMap[selectedCategory]);
        if (!response.ok) throw new Error("Excel not found");

        const arrayBuffer = await response.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        const fiSet = new Set();
        rows.flat().forEach(cell => {
          if (typeof cell === "string" && cell.trim().length > 2) {
            fiSet.add(cleanName(cell));
          }
        });

        fiNames = [...fiSet].sort();
        renderFiOptions(fiNames);

        fiSearch.disabled = false;
        fiSearch.value = "";
        fiSearch.placeholder = "-- Select FI --";

      } catch (err) {
        console.error("Excel load error:", err);
        fiSearch.value = "Error loading FIs";
      }
    });
  }

  /* CLEAN NAME  */
  function cleanName(name) {
    return name.replace(/\s+/g, " ").replace(/\.$/, "").trim();
  }

  function renderFiOptions(list) {
    fiOptionsContainer.innerHTML = "";
    if (list.length === 0) {
      const div = document.createElement("div");
      div.className = "select-option no-results";
      div.textContent = "No FIs found";
      fiOptionsContainer.appendChild(div);
      return;
    }

    list.forEach(fi => {
      const div = document.createElement("div");
      div.className = "select-option";
      div.textContent = fi;
      div.addEventListener("click", () => {
        fiSearch.value = fi;
        fiHiddenInput.value = fi;
        fiOptionsContainer.style.display = "none";
      });
      fiOptionsContainer.appendChild(div);
    });
  }

  function filterList(list, query) {
    const tokens = String(query || "").toLowerCase().trim().split(/\s+/).filter(Boolean);
    if (!tokens.length) return list;
    return list.filter(name => {
      const n = name.toLowerCase();
      return tokens.every(t => n.includes(t));
    });
  }

  if (fiSearch) {
    fiSearch.addEventListener("focus", () => {
      if (fiNames.length > 0) {
        fiOptionsContainer.style.display = "block";
      }
    });

    fiSearch.addEventListener("input", () => {
      const filtered = filterList(fiNames, fiSearch.value);
      renderFiOptions(filtered);
      fiOptionsContainer.style.display = "block";
      fiHiddenInput.value = "";
    });

    document.addEventListener("click", (e) => {
      if (!e.target.closest(".searchable-select")) {
        fiOptionsContainer.style.display = "none";
      }
    });
  }

  /* BALANCE SHEET LOGIC */
  if (incorporationDateInput && balanceSheetSection) {
    incorporationDateInput.addEventListener("change", function () {
      while (balanceSheetSection.firstChild) {
  balanceSheetSection.removeChild(balanceSheetSection.firstChild);
}


      const incorporationDate = new Date(this.value);
      const today = new Date();
      if (isNaN(incorporationDate)) return;

      let years = today.getFullYear() - incorporationDate.getFullYear();
      if (
        today.getMonth() < incorporationDate.getMonth() ||
        (today.getMonth() === incorporationDate.getMonth() &&
          today.getDate() < incorporationDate.getDate())
      ) {
        years--;
      }

      if (years < 1) {
        balanceSheetSection.innerHTML =
          "<p><strong>No balance sheet required (FI age < 1 year).</strong></p>";
        return;
      }

      for (let i = 1; i <= Math.min(years, 3); i++) {
        const div = document.createElement("div");
        div.className = "upload-box";
        div.innerHTML = `
          <label>Balance Sheet – Year ${i}</label>
          <input type="file" name="balance_sheet_year_${i}" accept=".pdf,.xlsx" required>
        `;
        balanceSheetSection.appendChild(div);
      }
      if (isEdit) {
        const bsInputs = balanceSheetSection.querySelectorAll('input[type="file"]');
        bsInputs.forEach(inp => { inp.required = false; });
      }
    });
  }

  /* FORM SUBMIT (FINAL & GUARANTEED) */
  if (!fiForm) return;

  fiForm.addEventListener("submit", async (e) => {
    e.preventDefault(); // 🔴 PREVENTS 405
    console.log(
  [...fiForm.querySelectorAll('input[type="file"]')].map(i => i.name)
);

    console.log("FI submit clicked");

    const userId = localStorage.getItem("userId");
    const signupData = localStorage.getItem("signupData");

    const formData = new FormData(fiForm);

    if (userId) {
      formData.append("userId", userId);
    } else if (signupData) {
      formData.append("signupData", signupData);
    } else {
      alert("Session expired. Please signup again.");
      window.location.href = "signup.html";
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/register/fi", {
        method: "POST",
        body: formData
      });

      console.log("Response status:", res.status);

      const data = await res.json();
      console.log("Response data:", data);

      if (!data.success) {
        throw new Error(data.message || "FI registration failed");
      }

      // ✅ Store the new userId, username and clear signup data
      if (data.userId) {
        localStorage.setItem("userId", data.userId);
      }
      if (data.username) {
        localStorage.setItem("username", data.username);
      }
      localStorage.removeItem("signupData");

      alert("FI registration successful ✅");
      window.location.href = "dashboard.html";

    } catch (err) {
      console.error("FI registration error:", err);
      alert(`Error submitting FI registration: ${err.message}`);
    }
  });

  async function prefillFromLatest() {
    try {
      const userId = localStorage.getItem("userId");
      if (!userId) return;
      const res = await fetch(`http://localhost:5000/api/register/registrations/by-user/${userId}`);
      if (!res.ok) return;
      const result = await res.json();
      if (!result.success || !result.data) return;
      const reg = result.data;
      const form = typeof reg.form_data === "string" ? JSON.parse(reg.form_data || "{}") : (reg.form_data || {});

      if (fiCategorySelect && form.fi_category) {
        fiCategorySelect.value = form.fi_category;
        fiCategorySelect.dispatchEvent(new Event("change"));
      }
      
      // Wait for FIs to load then prefill search and hidden input
      if (form.fi_name) {
        const checkLoaded = setInterval(() => {
          if (fiNames.length > 0) {
            fiSearch.value = form.fi_name;
            fiHiddenInput.value = form.fi_name;
            clearInterval(checkLoaded);
          }
        }, 200);
        setTimeout(() => clearInterval(checkLoaded), 10000); // timeout after 10s
      }

      if (incorporationDateInput && form.incorporation_date) {
        incorporationDateInput.value = form.incorporation_date;
        incorporationDateInput.dispatchEvent(new Event("change"));
      }
      const fiu = fiForm.querySelector('[name="fiu_registration_id"]');
      if (fiu && form.fiu_registration_id) fiu.value = form.fiu_registration_id;

      const fileInputs = fiForm.querySelectorAll('input[type="file"]');
      fileInputs.forEach(inp => { inp.required = false; });
    } catch {}
  }

  if (isEdit) {
    prefillFromLatest();
  }

});
