const API = "http://127.0.0.1:5000/api/admin";

function logout() {
  localStorage.removeItem("adminId");
  localStorage.removeItem("adminUsername");
  localStorage.removeItem("admin");
  location.href = "admin-login.html";
}

const id = new URLSearchParams(location.search).get("registrationId");
if (!id || id === "undefined") {
  alert("Invalid registration ID");
  throw new Error("Invalid registrationId");
}

fetch(`${API}/registration/${id}`)
  .then(r => r.json())
  .then(d => {
    if (!d.success || !d.data) return;

    const reg = d.data;

    // FIX: Parse files JSON string
    reg.files =
      typeof reg.files === "string"
        ? JSON.parse(reg.files)
        : reg.files || [];

    // FIX: Parse form_data JSON string
    let form = {};
    try {
      form = typeof reg.form_data === "string"
        ? JSON.parse(reg.form_data)
        : reg.form_data || {};
    } catch (e) {
      console.error("form_data parse error:", e);
    }

    /* ===== LEFT PANEL DATA ===== */
    document.getElementById("category").innerText =
      reg.category || "-";

    document.getElementById("subCategory").innerText =
      (() => {
        const cat = (reg.category || "").toLowerCase();
        if (cat === "bank") return form.bank_category || "-";
        if (cat === "fi") return form.fi_category || "-";
        if (cat === "other") return form.other_category || "-";
        return form.sub_category || "-";
      })();

    document.getElementById("orgName").innerText =
      (form.bank_fi_name || form.fi_name || form.organization_name || form.other_name || "-");

    document.getElementById("fullName").innerText =
      form.official_full_name || form.full_name || "-";

    document.getElementById("officialEmail").innerText =
      form.official_email || "-";

    document.getElementById("userEmail").innerText =
      form.user_email || "-";

    document.getElementById("designation").innerText =
      form.designation || "-";

    document.getElementById("contactNumber").innerText =
      form.contact_number || "-";

    document.getElementById("dateIncorporation").innerText =
      form.date_of_incorporation || form.incorporation_date || "-";

    document.getElementById("fiuId").innerText =
      form.fiu_registration_id || "-";

    // Initialize global action button visual state based on onboarding_status
    const regApproveBtn = document.getElementById("regApproveBtn");
    const regRejectBtn = document.getElementById("regRejectBtn");
    if (regApproveBtn && regRejectBtn) {
      regApproveBtn.classList.remove("approved");
      regRejectBtn.classList.remove("rejected");
      if (reg.onboarding_status === "Approved") {
        regApproveBtn.classList.add("approved");
      } else if (reg.onboarding_status === "Rejected") {
        regRejectBtn.classList.add("rejected");
      }
    }

    /* ===== RIGHT PANEL FILES ===== */
    const filesList = document.getElementById("filesList");
    const fileSearchInput = document.getElementById("fileSearchInput");
    let allFiles = [];

    const renderFiles = (files) => {
      filesList.innerHTML = "";
      if (!Array.isArray(files) || files.length === 0) {
        filesList.innerHTML = "<div class='file-item'>No files found</div>";
        return;
      }

      // 🔒 DEDUPLICATE FILES BY TYPE (IMPORTANT FIX)
      const seen = new Set();

      files.forEach(f => {
        if (!f || !f.file_type) return;
        if (seen.has(f.file_type)) return;
        seen.add(f.file_type);

        const approved = f.status === "Approved";
        const rejected = f.status === "Rejected";

        filesList.innerHTML += `
          <div class="file-item">
            <div class="file-name">${f.file_type.toUpperCase()}</div>
            <div class="file-actions">
              <button class="view-btn" onclick="openFile(${f.id})">
                VIEW DETAILS
              </button>

              <button
                class="approve-btn-small ${approved ? "active" : ""}"
                onclick="updateFile(${f.id}, 'Approved', this)">
                APPROVE
              </button>

              <button
                class="reject-btn-small ${rejected ? "active" : ""}"
                onclick="updateFile(${f.id}, 'Rejected', this)">
                REJECT
              </button>
            </div>
          </div>
        `;
      });
    };

    allFiles = reg.files || [];
    renderFiles(allFiles);

    if (fileSearchInput) {
      fileSearchInput.addEventListener("input", (e) => {
        const term = e.target.value.toLowerCase().trim();
        const filtered = allFiles.filter(f => 
          f.file_type && f.file_type.toLowerCase().includes(term)
        );
        renderFiles(filtered);
      });
    }
  })
  .catch(err => console.error("Admin details error:", err));

/* ===== FILE VIEW ===== */
function openFile(fileId) {
  window.open(`${API}/file/view/${fileId}`, "_blank");
}

/* ===== FILE STATUS UPDATE (ONLY ONE ACTIVE AT A TIME) ===== */
function updateFile(fileId, status, btn) {
  console.log("UPDATE FILE CALLED:", fileId, status);
  const actionCell = btn.parentElement;
  const approveBtn = actionCell.querySelector(".approve-btn-small");
  const rejectBtn = actionCell.querySelector(".reject-btn-small");

  // Toggle off if clicking already active
  if (status === "Approved" && approveBtn.classList.contains("active")) {
    status = "Pending";
  }
  if (status === "Rejected" && rejectBtn.classList.contains("active")) {
    status = "Pending";
  }

  fetch(`${API}/file/${fileId}/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status })
  })
    .then(() => {
      // If rejected, ask for remark and send to user dashboard
      if (status === "Rejected") {
        const id = new URLSearchParams(location.search).get("registrationId");
        const note = prompt("Enter a remark for the user about this file (optional):");
        if (note && note.trim()) {
          fetch(`${API}/registration/${id}/remark`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ file_id: fileId, remark: note.trim() })
          }).catch(err => console.error("Remark send error:", err));
        }
      }
      // Reset both buttons
      approveBtn.classList.remove("active");
      rejectBtn.classList.remove("active");

      // Activate only the selected one
      if (status === "Approved") {
        approveBtn.classList.add("active");
      } else if (status === "Rejected") {
        rejectBtn.classList.add("active");
      }
    })
    .catch(err => console.error("Status update error:", err));
}

/* ===== GLOBAL REGISTRATION STATUS (CENTER BUTTONS) ===== */
function toggleRegistrationStatus(targetStatus) {
  const id = new URLSearchParams(location.search).get("registrationId");
  const approveBtn = document.getElementById("regApproveBtn");
  const rejectBtn = document.getElementById("regRejectBtn");

  // Determine current active state
  const approveActive = approveBtn.classList.contains("approved");
  const rejectActive = rejectBtn.classList.contains("rejected");

  // Toggle logic: clicking active returns to Under Process
  let newStatus = targetStatus;
  if (targetStatus === "Approved" && approveActive) {
    newStatus = "Under Process";
  } else if (targetStatus === "Rejected" && rejectActive) {
    newStatus = "Under Process";
  }

  // Confirm only for final onboarding actions
  if (newStatus === "Approved" || newStatus === "Rejected") {
    const verb = newStatus.toLowerCase();
    const ok = confirm(`Are you sure you want to ${verb} this for onboarding?`);
    if (!ok) return;
  }

  fetch(`${API}/registration/${id}/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: newStatus })
  })
    .then(() => {
      // Visual toggle
      approveBtn.classList.remove("approved");
      rejectBtn.classList.remove("rejected");
      if (newStatus === "Approved") {
        approveBtn.classList.add("approved");
      } else if (newStatus === "Rejected") {
        rejectBtn.classList.add("rejected");
      }
    })
    .catch(err => console.error("Registration status update error:", err));
}

/* ===== SEND GENERAL REMARK TO USER DASHBOARD ===== */
function sendRemark() {
  const id = new URLSearchParams(location.search).get("registrationId");
  const input = document.getElementById("remarkInput");
  if (!input || !input.value.trim()) {
    alert("Please enter a remark");
    return;
  }
  const text = input.value.trim();
  fetch(`${API}/registration/${id}/remark`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ remark: text })
  })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        input.value = "";
        alert("Remark sent to user dashboard");
      } else {
        alert("Failed to send remark");
      }
    })
    .catch(err => console.error("Remark send error:", err));
}
