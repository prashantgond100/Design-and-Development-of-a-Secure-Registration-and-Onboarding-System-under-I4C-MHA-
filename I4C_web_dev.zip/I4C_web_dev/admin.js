const API = "http://127.0.0.1:5000/api/admin";

/* ================= ADMIN LOGIN ================= */
function adminLogin() {
  fetch(API + "/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: username.value,
      password: password.value
    })
  })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        localStorage.setItem("adminId", d.admin.id);
        localStorage.setItem("adminUsername", d.admin.username);
        localStorage.setItem("admin", JSON.stringify(d.admin));
        location.href = "admin-home.html";
      } else {
        alert("Login failed");
      }
    })
    .catch(err => {
      console.error("Admin login error:", err);
    });
}

function logout() {
  localStorage.removeItem("adminId");
  localStorage.removeItem("adminUsername");
  localStorage.removeItem("admin");
  location.href = "admin-login.html";
}

/* ================= ADMIN HOME ================= */
function openList(status) {
  location.href = `admin-list.html?status=${status}`;
}

/* ================= ADMIN HOME COUNTS ================= */
if (location.pathname.includes("admin-home")) {
  loadHomeCounts();
}

function loadHomeCounts() {
  const setCount = (id, n) => {
    const el = document.getElementById(id);
    if (el) el.innerText = typeof n === "number" ? n : "-";
  };

  Promise.all([
    fetch(`${API}/registrations/Pending`).then(r => r.json()).catch(() => ({ success: false, data: [] })),
    fetch(`${API}/registrations/Under%20Process`).then(r => r.json()).catch(() => ({ success: false, data: [] })),
    fetch(`${API}/registrations/Completed`).then(r => r.json()).catch(() => ({ success: false, data: [] }))
  ]).then(([pending, under, completed]) => {
    const p = Array.isArray(pending.data) ? pending.data.length : 0;
    const u = Array.isArray(under.data) ? under.data.length : 0;
    const c = Array.isArray(completed.data) ? completed.data.length : 0;
    setCount("pendingCount", p);
    setCount("underCount", u);
    setCount("completedCount", c);
    setCount("receivedCount", p + u + c);
  });
}

/* ================= ADMIN LIST ================= */
if (location.pathname.includes("admin-list")) {
  const status = new URLSearchParams(location.search).get("status");

  fetch(`${API}/registrations/${status}`)
    .then(r => r.json())
    .then(d => {
      tableBody.innerHTML = "";

      if (!d.success || !Array.isArray(d.data)) return;

      d.data.forEach(r => {
        tableBody.innerHTML += `
          <tr>
            <td>${r.username || "-"}</td>
            <td>${r.category ? r.category.toUpperCase() : "-"}</td>
            <td>${r.onboarding_status || "-"}</td>
            <td>
              <button onclick="viewDetails(${r.id})">
                View Details
              </button>
            </td>
          </tr>
        `;
      });
    })
    .catch(err => {
      console.error("Admin list fetch error:", err);
    });
}

function viewDetails(id) {
  location.href = `admin-details.html?registrationId=${id}`;
}

/* ================= ADMIN DETAILS ================= */
if (location.pathname.includes("admin-details")) {
  const id = new URLSearchParams(location.search).get("registrationId");

  fetch(`${API}/registration/${id}`)
    .then(r => r.json())
    .then(d => {
      if (!d.success || !d.data) return;

      const reg = d.data;

      /* ✅ FIX #1 — SAFE form_data PARSING */
      let form = {};
      try {
        form =
          typeof reg.form_data === "string"
            ? JSON.parse(reg.form_data)
            : reg.form_data || {};
      } catch (e) {
        console.error("form_data parse error:", e);
      }

      /* ===== LEFT SIDE DETAILS ===== */
      document.getElementById("username").innerText =
        reg.username || "-";

      document.getElementById("category").innerText =
        reg.category ? reg.category.toUpperCase() : "-";

      document.getElementById("fullName").innerText =
        form.full_name || "-";

      document.getElementById("officialEmail").innerText =
        form.official_email || "-";

      document.getElementById("userEmail").innerText =
        form.user_email || "-";

      document.getElementById("designation").innerText =
        form.designation || "-";

      document.getElementById("contactNumber").innerText =
        form.contact_number || "-";

      document.getElementById("dateIncorporation").innerText =
        form.date_of_incorporation || "-";

      document.getElementById("fiuId").innerText =
        form.fiu_registration_id || "-";

      /* ✅ FIX #2 — FILES HANDLING (NO UI BREAK) */
      const filesDiv = document.getElementById("files");
      filesDiv.innerHTML = "";

      const fileList = Array.isArray(reg.files)
        ? reg.files.filter(f => f && f.id)
        : [];

      if (fileList.length === 0) {
        filesDiv.innerHTML = "<p>No files uploaded</p>";
      }

      fileList.forEach(f => {
        filesDiv.innerHTML += `
          <div class="file-row">
            <span>${f.file_type || "Unknown File"}</span>
            <button onclick="openFile(${f.id})">
              View Details
            </button>
          </div>
        `;
      });
    })
    .catch(err => {
      console.error("Admin details fetch error:", err);
    });
}

/* ================= FILE VIEW ================= */
function openFile(id) {
  window.open(`${API}/file/view/${id}`, "_blank");
}

/* ================= STATUS UPDATE ================= */
function updateStatus(status) {
  const id = new URLSearchParams(location.search).get("registrationId");

  fetch(`${API}/registration/${id}/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status })
  })
    .then(() => {
      alert("Status updated successfully");
      location.reload();
    })
    .catch(err => {
      console.error("Status update error:", err);
    });
}
