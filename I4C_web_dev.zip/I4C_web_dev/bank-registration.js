/* 
   NCRP Bank Registration – Category-wise XLSX Loader
*/

document.addEventListener("DOMContentLoaded", () => {
  console.log("bank-registration.js loaded");

  /* DOM ELEMENTS */
  const bankCategorySelect = document.getElementById("bank_category");
  const bankSearch = document.getElementById("bank_search");
  const bankOptionsContainer = document.getElementById("bank_options");
  const bankHiddenInput = document.getElementById("bank_selector");
  const bankForm = document.getElementById("bankForm");
  const incorporationDateInput = document.getElementById("incorporationDate");
  const balanceSheetSection = document.getElementById("balanceSheetUploadSection");
  const params = new URLSearchParams(location.search);
  const isEdit = params.get("edit") === "1";

  /* CATEGORY XLSX MAP */
  const categoryExcelMap = {
    "SBI": "banks_list/sbi.xlsx",
    "NATIONALISED_BANKS": "banks_list/nationalised_banks.xlsx",
    "PRIVATE SECTOR BANKS- INDIAN BANKS": "banks_list/private_indian_banks.xlsx",
    "PRIVATE SECTOR BANKS- FOREIGN BANKS": "banks_list/private_foreign_banks.xlsx",
    "SCHEDULED STATE CO OP BANKS": "banks_list/scheduled_state_coop.xlsx",
    "NON-SCHEDULED STATE CO OP BANKS": "banks_list/non_scheduled_state_coop.xlsx",
    "CO OP BANK- SCHEDULED URBAN CO OP BANKS": "banks_list/scheduled_urban_coop.xlsx",
    "CO OP BANK- NON-SCHEDULED URBAN CO OP BANKS": "banks_list/non_scheduled_urban_coop.xlsx",
    "CO OP BANKS- STATE CO OP BANK": "banks_list/state_coop_banks.xlsx",
    "CO OP BANKS- DISTRICT CO OP BANK": "banks_list/district_coop_banks.xlsx",
    "REGIONAL RURAL BANKS": "banks_list/rrb.xlsx"
  };
  let bankNames = [];

  /* INITIAL STATE */
  if (bankSearch) {
    bankSearch.disabled = true;
    bankSearch.value = "Select bank category first";
  }

  /* CATEGORY CHANGE */
  if (bankCategorySelect && bankSearch) {
    bankCategorySelect.addEventListener("change", async () => {
      const selectedCategory = bankCategorySelect.value;

      bankSearch.disabled = true;
      bankSearch.value = "Loading banks...";
      bankOptionsContainer.innerHTML = "";
      bankHiddenInput.value = "";

      if (!categoryExcelMap[selectedCategory]) {
        bankSearch.value = "";
        bankSearch.placeholder = "-- Select Bank --";
        return;
      }

      try {
        const response = await fetch(categoryExcelMap[selectedCategory]);
        if (!response.ok) throw new Error("Excel file not found");

        const arrayBuffer = await response.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        const bankSet = new Set();
        rows.flat().forEach(cell => {
          if (typeof cell === "string" && cell.trim().length > 2) {
            bankSet.add(cleanName(cell));
          }
        });

        bankNames = [...bankSet].sort();
        renderBankOptions(bankNames);

        bankSearch.disabled = false;
        bankSearch.value = "";
        bankSearch.placeholder = "-- Select Bank --";

      } catch (err) {
        console.error("Excel load error:", err);
        bankSearch.value = "Error loading banks";
        alert("Error loading banks from Excel file.");
      }
    });
  }

  /* CLEAN BANK NAME */
  function cleanName(name) {
    return name.replace(/\s+/g, " ").replace(/\.$/, "").trim();
  }

  function renderBankOptions(list) {
    bankOptionsContainer.innerHTML = "";
    if (list.length === 0) {
      const div = document.createElement("div");
      div.className = "select-option no-results";
      div.textContent = "No banks found";
      bankOptionsContainer.appendChild(div);
      return;
    }

    list.forEach(bank => {
      const div = document.createElement("div");
      div.className = "select-option";
      div.textContent = bank;
      div.addEventListener("click", () => {
        bankSearch.value = bank;
        bankHiddenInput.value = bank;
        bankOptionsContainer.style.display = "none";
      });
      bankOptionsContainer.appendChild(div);
    });
  }

  function filterList(list, query) {
    const tokens = String(query || "").toLowerCase().trim().split(/\s+/).filter(Boolean);
    if (!tokens.length) return list;
    return list.filter(name => {
      const n = name.toLowerCase();
      return tokens.every(t => n.includes(t));
    });
  }

  if (bankSearch) {
    bankSearch.addEventListener("focus", () => {
      if (bankNames.length > 0) {
        bankOptionsContainer.style.display = "block";
      }
    });

    bankSearch.addEventListener("input", () => {
      const filtered = filterList(bankNames, bankSearch.value);
      renderBankOptions(filtered);
      bankOptionsContainer.style.display = "block";
      bankHiddenInput.value = ""; // Clear hidden value if typing
    });

    // Close dropdown when clicking outside
    document.addEventListener("click", (e) => {
      if (!e.target.closest(".searchable-select")) {
        bankOptionsContainer.style.display = "none";
      }
    });
  }

  /* BALANCE SHEET LOGIC */
  if (incorporationDateInput && balanceSheetSection) {
    incorporationDateInput.addEventListener("change", function () {
      balanceSheetSection.innerHTML = "";

      const incorporationDate = new Date(this.value);
      const today = new Date();
      if (isNaN(incorporationDate)) return;

      let years = today.getFullYear() - incorporationDate.getFullYear();
      if (
        today.getMonth() < incorporationDate.getMonth() ||
        (today.getMonth() === incorporationDate.getMonth() &&
          today.getDate() < incorporationDate.getDate())
      ) {
        years--;
      }

      if (years < 1) {
        balanceSheetSection.innerHTML =
          "<p><strong>No balance sheet required (Bank age < 1 year).</strong></p>";
        return;
      }

      for (let i = 1; i <= Math.min(years, 3); i++) {
        const div = document.createElement("div");
        div.className = "upload-box";
        div.innerHTML = `
          <label>Balance Sheet – Year ${i}</label>
          <input type="file" name="balance_sheet_year_${i}" accept=".pdf,.xlsx" required>
        `;
        balanceSheetSection.appendChild(div);
      }
      if (isEdit) {
        const bsInputs = balanceSheetSection.querySelectorAll('input[type="file"]');
        bsInputs.forEach(inp => { inp.required = false; });
      }
    });
  }

  async function prefillFromLatest() {
    try {
      const userId = localStorage.getItem("userId");
      if (!userId) return;
      const res = await fetch(`http://localhost:5000/api/register/registrations/by-user/${userId}`);
      if (!res.ok) return;
      const result = await res.json();
      if (!result.success || !result.data) return;
      const reg = result.data;
      const form = typeof reg.form_data === "string" ? JSON.parse(reg.form_data || "{}") : (reg.form_data || {});

      if (bankCategorySelect && form.bank_category) {
        bankCategorySelect.value = form.bank_category;
        bankCategorySelect.dispatchEvent(new Event("change"));
      }
      
      // Wait for banks to load then prefill search and hidden input
      if (form.bank_fi_name) {
        const checkLoaded = setInterval(() => {
          if (bankNames.length > 0) {
            bankSearch.value = form.bank_fi_name;
            bankHiddenInput.value = form.bank_fi_name;
            clearInterval(checkLoaded);
          }
        }, 200);
        setTimeout(() => clearInterval(checkLoaded), 10000); // timeout after 10s
      }

      if (incorporationDateInput && form.incorporation_date) {
        incorporationDateInput.value = form.incorporation_date;
        incorporationDateInput.dispatchEvent(new Event("change"));
      }
      const fiu = document.querySelector('[name="fiu_registration_id"]');
      if (fiu && form.fiu_registration_id) fiu.value = form.fiu_registration_id;

      const fileInputs = bankForm.querySelectorAll('input[type="file"]');
      fileInputs.forEach(inp => { inp.required = false; });
    } catch {}
  }

  if (isEdit) {
    prefillFromLatest();
  }

  /* ================= FORM SUBMIT (EDITED) ================= */
  if (!bankForm) return;

  bankForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    try {
      const formData = new FormData(bankForm);

      // ✅ Handle new registration flow (delayed user creation)
      const userId = localStorage.getItem("userId");
      const signupData = localStorage.getItem("signupData");

      if (userId) {
        formData.append("userId", userId);
      } else if (signupData) {
        formData.append("signupData", signupData);
      } else {
        alert("Session expired. Please signup again.");
        window.location.href = "signup.html";
        return;
      }

      const res = await fetch("http://localhost:5000/api/register/bank", {
        method: "POST",
        body: formData
      });

      const data = await res.json();

      if (!data.success) {
        throw new Error(data.message || "Bank registration failed");
      }

      // ✅ Store the new userId and clear signup data
      if (data.userId) {
        localStorage.setItem("userId", data.userId);
      }
      if (data.username) {
        localStorage.setItem("username", data.username);
      }
      localStorage.removeItem("signupData");

      alert("Bank registration successful ✅");
      window.location.href = "dashboard.html";

    } catch (err) {
      console.error("Bank registration error:", err);
      alert(`Error submitting bank registration: ${err.message}`);
    }
  });
});
