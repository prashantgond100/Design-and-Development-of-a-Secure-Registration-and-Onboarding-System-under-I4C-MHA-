document.addEventListener("DOMContentLoaded", () => {

  /* ================= SESSION ================= */
  const userId = localStorage.getItem("userId", data.id);
  const username = localStorage.getItem("username", data.user_id);

  if (!userId) {
    alert("Session expired. Please login again.");
    localStorage.clear();
    window.location.href = "login.html";
    return;
  }

  /* ================= SHOW USER ================= */
  const usernameEl = document.getElementById("username");
  if (usernameEl && username) {
    usernameEl.innerText = `Username: ${username}`;
  }

  /* ================= CHECK STATUS ================= */
  const checkBtn = document.getElementById("checkStatusBtn");
  if (checkBtn) {
    checkBtn.addEventListener("click", async () => {

      const card = document.getElementById("statusCard");
      if (!card) return;

      card.style.display = "block";
      card.innerText = "Loading latest status...";

      const reg = await fetchLatestRegistration(userId);

      if (!reg) {
        card.innerHTML = `
<pre>
---------------------------------------------
 Registration Status
---------------------------------------------
 No registration found yet.
 Please complete registration first.
---------------------------------------------
</pre>`;
        return;
      }

      renderStatusCard(reg);
    });
  }

  /* ================= LOGOUT ================= */
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.clear();
      alert("Logged out successfully");
      window.location.href = "login.html";
    });
  }
});

/* ================================================= */
/* ===== FETCH LATEST REGISTRATION (SAFE) ============ */
/* ================================================= */
async function fetchLatestRegistration(userId) {
  try {
    const res = await fetch(
      `http://localhost:5000/api/registrations/by-user/${userId}`
    );

    if (!res.ok) throw new Error("Fetch failed");

    const result = await res.json();

    if (!result.success || !result.data) {
      return null;
    }

    return result.data;

  } catch (err) {
    console.error("Dashboard fetch error:", err);
    return null;
  }
}

/* ================= HELPERS ================= */
function hasFile(files, keyword) {
  if (!Array.isArray(files)) return false;
  return files.some(
    f =>
      f.file_type &&
      f.file_type.toLowerCase().includes(keyword.toLowerCase())
  );
}

/* ================= RENDER ================= */
function renderStatusCard(reg) {
  const card = document.getElementById("statusCard");
  if (!card) return;

  const files = reg.files || [];
  const submittedDate = reg.created_at
    ? new Date(reg.created_at).toDateString()
    : "N/A";

  const onboardingStatus = reg.onboarding_status || "Pending";

  card.innerHTML = `
<pre style="
  font-size: 18px;
  line-height: 1.7;
  font-family: Consolas, 'Courier New', monospace;
">
---------------------------------------------
 Registration Summary
---------------------------------------------
 Category            : ${reg.category.toUpperCase()}
 Submitted On        : ${submittedDate}
 Submission Status   : Submitted
 Onboarding Status   : ${onboardingStatus}
---------------------------------------------
 Documents Uploaded
---------------------------------------------
 ${hasFile(files,"rbi") ? "✔" : "✖"} RBI Certificate
 ${hasFile(files,"gst") ? "✔" : "✖"} GST Certificate
 ${hasFile(files,"fiu") ? "✔" : "✖"} FIU Screenshot
 ${hasFile(files,"balance_sheet_year_1") ? "✔" : "✖"} Balance Sheet Year 1
 ${hasFile(files,"balance_sheet_year_2") ? "✔" : "✖"} Balance Sheet Year 2
 ${hasFile(files,"balance_sheet_year_3") ? "✔" : "✖"} Balance Sheet Year 3
 ${hasFile(files,"nodal") ? "✔" : "✖"} Nodal Officer Sheet
 ${hasFile(files,"terms") ? "✔" : "✖"} Terms & Conditions
---------------------------------------------
</pre>
`;
}
