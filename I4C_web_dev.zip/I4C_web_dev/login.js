document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const toggleBtn = document.getElementById("togglePassword");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      login();
    });
  }
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      const input = document.getElementById("password");
      const isPass = input.getAttribute("type") === "password";
      input.setAttribute("type", isPass ? "text" : "password");
      toggleBtn.textContent = isPass ? "Hide" : "Show";
    });
  }
});

function login() {
  const userId = document.getElementById("userId").value.trim();
  const password = document.getElementById("password").value.trim();
  const err = document.getElementById("errorMsg");
  const btn = document.getElementById("loginBtn");

  if (!userId || !password) {
    if (err) {
      err.style.display = "block";
      err.textContent = "User ID and Password are required";
    } else {
      alert("User ID and Password are required");
    }
    return;
  }

  if (err) {
    err.style.display = "none";
    err.textContent = "";
  }
  if (btn) {
    btn.classList.add("loading");
    btn.disabled = true;
    btn.textContent = "Logging in…";
  }

  fetch("http://127.0.0.1:5000/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, password })
  })
    .then(res => res.json())
    .then(data => {
      if (!data.success) {
        localStorage.clear();
        if (err) {
          err.style.display = "block";
          err.textContent = data.message || "Invalid login";
        } else {
          alert(data.message || "Invalid login");
        }
        if (btn) {
          btn.classList.remove("loading");
          btn.disabled = false;
          btn.textContent = "Login";
        }
        return;
      }

      localStorage.setItem("userId", data.userId);       // numeric DB id
      localStorage.setItem("username", data.username);   // email / username

      window.location.href = "dashboard.html";
    })
    .catch(err => {
      console.error("Login error:", err);
      localStorage.clear();
      if (err) {
        err.style.display = "block";
        err.textContent = "Login failed";
      } else {
        alert("Login failed");
      }
    })
    .finally(() => {
      if (btn) {
        btn.classList.remove("loading");
        btn.disabled = false;
        btn.textContent = "Login";
      }
    });
}
