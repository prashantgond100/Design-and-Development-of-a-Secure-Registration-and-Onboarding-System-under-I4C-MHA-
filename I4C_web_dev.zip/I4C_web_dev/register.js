document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("bankForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = {
      full_name: form.full_name.value.trim(),
      official_email: form.official_email.value.trim(),
      user_email: form.user_email.value.trim(),
      designation: form.designation.value.trim(),
      contact_number: form.contact_number.value.trim(),
      userId: form.userId.value.trim(),
      password: form.password.value.trim()
    };

    // basic validation
    for (let key in payload) {
      if (!payload[key]) {
        alert(`Missing field: ${key}`);
        return;
      }
    }

    // Instead of calling backend, store data temporarily
    localStorage.setItem("signupData", JSON.stringify(payload));
    
    alert("Details saved! Please complete the registration process. ✅");
    window.location.href = "home.html";
  });
});
