const express = require("express");
const router = express.Router();
const db = require("./db");
const multer = require("multer");

/* ================= MULTER CONFIG ================= */
const upload = multer({
  storage: multer.memoryStorage()
});

/* ================= COMMON REGISTER HANDLER ================= */
function register(category) {
  return (req, res) => {
    console.log("✅ REGISTER HIT:", category);
    console.log("BODY:", req.body);
    console.log(
      "FILES:",
      req.files ? req.files.map(f => f.fieldname) : []
    );

    /* ================= USER VALIDATION ================= */
    const userId = Number(req.body.userId);

    if (!userId || Number.isNaN(userId)) {
      return res.status(401).json({
        success: false,
        message: "Invalid user session"
      });
    }

    /* ================= MERGE SIGNUP/BANK FORM ================= */
    const signupSql = `
      SELECT form_data 
      FROM registrations 
      WHERE user_id = ? AND category IN ('signup','bank')
      ORDER BY created_at DESC
      LIMIT 1
    `;

    db.query(signupSql, [userId], (signupErr, signupRows) => {
      if (signupErr) {
        console.error("❌ Signup fetch error:", signupErr);
      }
      let signupForm = {};
      try {
        const raw = signupRows && signupRows.length ? signupRows[0].form_data : "{}";
        signupForm = typeof raw === "string" ? JSON.parse(raw || "{}") : (raw || {});
      } catch (_) { signupForm = {}; }

      /* ================= CHECK EXISTING REGISTRATION ================= */
      const checkSql =
        "SELECT id, form_data FROM registrations WHERE user_id = ? LIMIT 1";

      db.query(checkSql, [userId], (checkErr, checkRes) => {
      if (checkErr) {
        console.error("❌ Registration check error:", checkErr);
        return res.status(500).json({
          success: false,
          message: "Server error"
        });
      }

      let registrationId;

      /* ================= CLEAN FORM DATA ================= */
        const cleanFormData = { ...signupForm, ...req.body };
      delete cleanFormData.userId;
      const formDataJson = JSON.stringify(cleanFormData);

      if (checkRes.length > 0) {
        // ✅ Registration already exists → reuse
          registrationId = checkRes[0].id;
          // Optionally update merged form_data on existing record
          const existingRaw = checkRes[0].form_data;
          let existingForm = {};
          try {
            existingForm = typeof existingRaw === "string" ? JSON.parse(existingRaw || "{}") : (existingRaw || {});
          } catch (_) { existingForm = {}; }
          const merged = { ...signupForm, ...existingForm, ...cleanFormData };
          const updSql = `
            UPDATE registrations 
            SET category = ?, form_data = ?, onboarding_status = 'Pending'
            WHERE id = ?
          `;
          db.query(updSql, [category, JSON.stringify(merged), registrationId], err => {
            if (err) console.error("❌ Update merged form_data error:", err);
          });
        saveFiles(registrationId);
      } else {
        // ✅ Create new registration
        const regSql = `
          INSERT INTO registrations 
          (user_id, category, form_data, onboarding_status)
          VALUES (?, ?, ?, 'Pending')
        `;

        db.query(
          regSql,
          [userId, category, formDataJson],
          (regErr, regResult) => {
            if (regErr) {
              console.error("❌ REG INSERT ERROR:", regErr);
              return res.status(500).json({
                success: false,
                message: "Registration failed"
              });
            }

            registrationId = regResult.insertId;
            saveFiles(registrationId);
          }
        );
      }

      /* ================= SAVE FILES FUNCTION ================= */
      function saveFiles(regId) {
        if (req.files && req.files.length > 0) {
          req.files.forEach(file => {
            const fileSql = `
              INSERT INTO files
              (registration_id, file_name, file_type, file_data)
              VALUES (?, ?, ?, ?)
            `;

            db.query(
              fileSql,
              [
                regId,
                file.originalname,
                file.fieldname,
                file.buffer
              ],
              err => {
                if (err) {
                  console.error(
                    "❌ File insert error:",
                    err,
                    file.fieldname
                  );
                }
              }
            );
          });
        }

        return res.status(200).json({
          success: true,
          message: `${category} registration saved`,
          registrationId: regId
        });
      }
      });
    });
  };
}

/* ================= REGISTRATION ROUTES ================= */
router.post("/bank", upload.any(), register("bank"));
router.post("/fi", upload.any(), register("fi"));
router.post("/other", upload.any(), register("other"));

/* ================= FETCH REGISTRATION BY USER ================= */
router.get("/registrations/by-user/:userId", (req, res) => {
  console.log("📥 Dashboard fetch hit for user:", req.params.userId);

  const userId = Number(req.params.userId);

  if (!userId) {
    return res.status(400).json({ success: false });
  }

  const parseSafe = (raw) => {
    if (!raw) return {};
    if (typeof raw === "object") return raw;
    if (typeof raw === "string") {
      if (raw.trim() === "[object Object]") return {};
      try { return JSON.parse(raw); } catch { return {}; }
    }
    return {};
  };

  const latestSql = `
    SELECT 
      r.id,
      r.user_id,
      r.category,
      r.form_data,
      r.created_at,
      r.onboarding_status,
      JSON_ARRAYAGG(
        JSON_OBJECT(
          'file_type', f.file_type,
          'file_name', f.file_name
        )
      ) AS files
    FROM registrations r
    LEFT JOIN files f ON r.id = f.registration_id
    WHERE r.user_id = ?
    GROUP BY r.id
    ORDER BY r.created_at DESC
    LIMIT 1
  `;

  db.query(latestSql, [userId], (err, latestRows) => {
    if (err) {
      console.error("❌ Fetch registration error:", err);
      return res.status(500).json({ success: false });
    }

    const latest = latestRows && latestRows.length ? latestRows[0] : null;

    const signupSql = `
      SELECT form_data 
      FROM registrations 
      WHERE user_id = ? AND category IN ('signup','bank')
      ORDER BY created_at DESC
      LIMIT 1
    `;

    db.query(signupSql, [userId], (err2, signupRows) => {
      if (err2) {
        console.error("❌ Fetch signup form_data error:", err2);
        return res.json({ success: true, data: latest });
      }

      const signupForm = signupRows && signupRows.length ? parseSafe(signupRows[0].form_data) : {};

      if (!latest) {
        return res.json({
          success: true,
          data: signupRows && signupRows.length ? {
            user_id: userId,
            category: "signup",
            form_data: signupForm,
            files: []
          } : null
        });
      }

      const latestForm = parseSafe(latest.form_data);
      const merged = { ...signupForm, ...latestForm };
      latest.form_data = merged;

      return res.json({ success: true, data: latest });
    });
  });
});

module.exports = router;
