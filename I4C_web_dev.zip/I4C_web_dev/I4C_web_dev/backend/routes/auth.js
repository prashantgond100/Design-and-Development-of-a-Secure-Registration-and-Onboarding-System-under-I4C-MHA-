const express = require("express");
const router = express.Router();
const db = require("./db");

/* ================= SIGN UP (WITH REGISTRATION + AUTO LOGIN) ================= */
router.post("/signup", (req, res) => {
  console.log("Signup hit", req.body);
  const {
    full_name,
    official_email,
    user_email,
    designation,
    contact_number,
    userId,
    password
  } = req.body;

  if (
    !full_name ||
    !official_email ||
    !user_email ||
    !designation ||
    !contact_number ||
    !userId ||
    !password
  ) {
    return res.status(400).json({
      success: false,
      message: "Missing required fields"
    });
  }

  /* 1️⃣ INSERT USER */
  const userSql =
    "INSERT INTO users (user_id, password) VALUES (?, ?)";

  db.query(userSql, [userId, password], (err, userResult) => {
    if (err) {
      console.error("Signup error (user insert):", err);
      if (err.code === "ER_DUP_ENTRY") {
        return res.status(400).json({
          success: false,
          message: "User already exists"
        });
      }
      return res.status(500).json({
        success: false,
        message: "Database error during user creation"
      });
    }

    const userDbId = userResult.insertId;

    /* 2️⃣ INSERT REGISTRATION */
    const formData = {
      full_name,
      official_email,
      user_email,
      designation,
      contact_number
    };

    const regSql = `
      INSERT INTO registrations (user_id, category, form_data)
      VALUES (?, ?, ?)
    `;

    db.query(
      regSql,
      [userDbId, "bank", JSON.stringify(formData)],
      (err2) => {
        if (err2) {
          console.error("Registration insert error:", err2);
          return res.status(500).json({
            success: false,
            message: "Registration failed: " + err2.message
          });
        }

        /* 3️⃣ AUTO LOGIN RESPONSE */
        return res.status(200).json({
          success: true,
          message: "Signup successful",
          userId: userDbId,       // 🔑 DB primary key
          username: userId        // 👈 login username
        });
      }
    );
  });
});

/* ================= LOGIN (OPTIONAL / FUTURE USE) ================= */
router.post("/login", (req, res) => {
  const { userId, password } = req.body;

  if (!userId || !password) {
    return res.status(400).json({
      success: false,
      message: "User ID and password are required"
    });
  }

  const sql =
    "SELECT id, user_id, password FROM users WHERE user_id = ?";

  db.query(sql, [userId], (err, result) => {
    if (err) {
      console.error("Login error:", err);
      return res.status(500).json({
        success: false,
        message: "Server error"
      });
    }

    if (result.length === 0 || result[0].password !== password) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials"
      });
    }

    return res.status(200).json({
      success: true,
      message: "Login successful",
      userId: result[0].id,
      username: result[0].user_id
    });
  });
});

module.exports = router;

