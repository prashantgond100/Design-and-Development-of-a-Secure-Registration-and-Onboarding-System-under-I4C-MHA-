const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "8001354567@Pg",
  database: "ncrp_db"
});

db.connect(err => {
  if (err) {
    console.error("MySQL connection error:", err);
  } else {
    console.log("MySQL connected ✅");
  }
});

module.exports = db;
