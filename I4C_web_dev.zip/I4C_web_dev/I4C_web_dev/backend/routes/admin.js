const express = require("express");
const router = express.Router();
const db = require("./db");

/* ================= ADMIN LOGIN ================= */
router.post("/login", (req, res) => {
  const { username, password } = req.body;

  db.query(
    "SELECT * FROM admins WHERE username=? AND password=?",
    [username, password],
    (err, rows) => {
      if (err) return res.status(500).json({ success: false });
      if (!rows.length)
        return res.json({ success: false, message: "Invalid credentials" });

      res.json({
        success: true,
        admin: { id: rows[0].id, username: rows[0].username }
      });
    }
  );
});

/* ================= LIST BY STATUS ================= */
router.get("/registrations/:status", (req, res) => {
  const status = req.params.status;

  const sql = `
    SELECT 
      r.id,
      r.category,
      r.onboarding_status,
      JSON_EXTRACT(r.form_data, '$.user_email') AS username
    FROM registrations r
    WHERE r.onboarding_status = ?
    ORDER BY r.created_at DESC
  `;

  db.query(sql, [status], (err, rows) => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true, data: rows });
  });
});

/* ================= DETAILS ================= */
router.get("/registration/:id", (req, res) => {
  const id = req.params.id;

  const sql = `
    SELECT r.*,
    JSON_ARRAYAGG(
      JSON_OBJECT(
        'id', f.id,
        'file_type', f.file_type,
        'file_name', f.file_name,
        'status', f.status
      )
    ) AS files
    FROM registrations r
    LEFT JOIN files f ON r.id = f.registration_id
    WHERE r.id = ?
    GROUP BY r.id
  `;

  db.query(sql, [id], (err, rows) => {
    if (err || !rows.length)
      return res.status(404).json({ success: false });

    res.json({ success: true, data: rows[0] });
  });
});

/* ================= VIEW FILE ================= */
router.get("/file/view/:id", (req, res) => {
  db.query(
    "SELECT file_data, file_name FROM files WHERE id=?",
    [req.params.id],
    (err, rows) => {
      if (err || !rows.length) return res.sendStatus(404);

      res.setHeader(
        "Content-Disposition",
        `inline; filename="${rows[0].file_name}"`
      );
      res.send(rows[0].file_data);
    }
  );
});

/* ================= UPDATE FILE STATUS ================= */
router.post("/file/:id/status", (req, res) => {
  const { status } = req.body;

  db.query(
    "UPDATE files SET status=? WHERE id=?",
    [status, req.params.id],
    () => res.json({ success: true })
  );
});

/* ================= UPDATE REGISTRATION STATUS ================= */
router.post("/registration/:id/status", (req, res) => {
  const { status } = req.body;

  db.query(
    "UPDATE registrations SET onboarding_status=? WHERE id=?",
    [status, req.params.id],
    () => res.json({ success: true })
  );
});

/* ================= UPDATE REMARK ================= */
router.post("/registration/:id/remark", (req, res) => {
  const { remark } = req.body;
  const id = req.params.id;

  db.query(
    "UPDATE registrations SET remark=? WHERE id=?",
    [remark, id],
    (err) => {
      if (err) return res.status(500).json({ success: false });
      res.json({ success: true });
    }
  );
});

/* ================= GET STATS ================= */
router.get("/stats", (req, res) => {
  const sql = `
    SELECT 
      onboarding_status as status, 
      COUNT(*) as count 
    FROM registrations 
    GROUP BY onboarding_status
  `;
  db.query(sql, (err, rows) => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true, data: rows });
  });
});

module.exports = router;
