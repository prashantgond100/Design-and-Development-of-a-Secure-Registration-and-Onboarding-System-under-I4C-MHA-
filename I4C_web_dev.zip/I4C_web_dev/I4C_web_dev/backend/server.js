const express = require('express');
const cors = require('cors');

const app = express(); // ✅ app FIRST

// middlewares
app.use(cors());
app.use(express.json());

// routes
const authRoutes = require("./routes/auth");
const adminRoutes = require('./routes/admin');
const registerRoutes = require("./routes/registration");

app.use("/api/admin", require("./routes/admin"));
 //  ADMIN APIs

app.use("/api/register", registerRoutes);


app.use("/api", authRoutes);        // 🔥 USER SIGNUP / LOGIN

// 404 handler for API routes
app.use("/api", (req, res) => {
  res.status(404).json({
    success: false,
    message: `API route not found: ${req.method} ${req.originalUrl}`
  });
});

// Error handler to ensure JSON response for all errors
app.use((err, req, res, next) => {
  console.error("Global error handler:", err);
  res.status(500).json({
    success: false,
    message: "Internal server error"
  });
});

// server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
