// Test script to verify admin details functionality
async function testAdminDetails() {
  console.log('Testing admin details functionality...');
  
  try {
    // Test fetching registration details
    const registrationId = 1; // Replace with a valid registration ID from your database
    const res = await fetch(`http://127.0.0.1:5000/api/admin/registration/${registrationId}`);
    
    console.log('Response status:', res.status);
    const data = await res.json();
    console.log('Response data:', data);
    
    if (data.success && data.data) {
      console.log('✅ Test passed! Registration details fetched successfully.');
      
      // Check if files are included correctly
      if (data.data.files) {
        console.log(`📋 Found ${Array.isArray(data.data.files) ? data.data.files.length : 0} files`);
        
        if (Array.isArray(data.data.files)) {
          data.data.files.forEach(file => {
            if (file) {
              console.log(`   - File: ${file.file_type}, Status: ${file.status || 'Pending'}`);
            }
          });
        }
      }
      
      // Verify form_data is correctly parsed
      const formData = typeof data.data.form_data === 'string' ? JSON.parse(data.data.form_data) : data.data.form_data;
      console.log('📋 Form data fields:', Object.keys(formData).join(', '));
      
    } else {
      console.log('❌ Test failed! Registration details not fetched.');
    }
  } catch (err) {
    console.error('❌ Test error:', err);
  }
}

testAdminDetails();