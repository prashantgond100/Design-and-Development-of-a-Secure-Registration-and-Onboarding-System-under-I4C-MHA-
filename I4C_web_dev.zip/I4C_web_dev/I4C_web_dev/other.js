document.addEventListener("DOMContentLoaded", () => {

  const form = document.getElementById("otherForm");
  const incorporationDateInput = document.getElementById("incorporation_date");
  const balanceSheetSection = document.getElementById("balanceSheetUploadSection");

  if (incorporationDateInput && balanceSheetSection) {
    incorporationDateInput.addEventListener("change", function () {
      while (balanceSheetSection.firstChild) {
  balanceSheetSection.removeChild(balanceSheetSection.firstChild);
}


      const incorporationDate = new Date(this.value);
      const today = new Date();
      if (isNaN(incorporationDate)) return;

      let years = today.getFullYear() - incorporationDate.getFullYear();
      const monthDiff = today.getMonth() - incorporationDate.getMonth();

      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < incorporationDate.getDate())) {
        years--;
      }

      if (years < 1) {
        balanceSheetSection.innerHTML =
          "<p><strong>No balance sheet required (Entity age < 1 year).</strong></p>";
        return;
      }

      for (let i = 1; i <= Math.min(years, 3); i++) {
        const div = document.createElement("div");
        div.className = "upload-box";
        div.innerHTML = `
          <label>Balance Sheet – Year ${i}</label>
          <input type="file" name="balance_sheet_year_${i}" required>
        `;
        balanceSheetSection.appendChild(div);
      }
    });
  }

  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const storedUserId = localStorage.getItem("userId");
      if (!storedUserId) {
        alert("Session expired. Please signup again.");
        window.location.href = "signup.html";
        return;
      }

      const formData = new FormData(form);
      formData.append("userId", storedUserId);

      try {
        const res = await fetch("http://localhost:5000/api/register/other", {
          method: "POST",
          body: formData
        });

        const data = await res.json();
        if (!data.success) throw new Error();

        alert("Other entity registration successful ✅");
        
        window.location.href = "dashboard.html";

      } catch (err) {
        console.error(err);
        alert("Error submitting Other registration ❌");
      }
    });
  }
});
