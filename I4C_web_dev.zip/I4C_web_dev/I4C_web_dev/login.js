const { response } = require("express");

function login() {
  const userId = document.getElementById("userId").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!userId || !password) {
    alert("User ID and Password are required");
    return;
  }

  fetch("http://127.0.0.1:5000/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId, password })
  })
    .then(res => res.json())
    .then(data => {
      if (!data.success) {
        localStorage.clear();
        alert(data.message || "Invalid login");
        return;
      }

      // ✅ FIXED HERE ⬇⬇⬇
      localStorage.setItem("userId", data.userId);       // numeric DB id
      localStorage.setItem("username", data.username);   // email / username

      window.location.href = "dashboard.html";
    })
    .catch(err => {
      console.error("Login error:", err);
      localStorage.clear();
      alert("Login failed");
    });
}
