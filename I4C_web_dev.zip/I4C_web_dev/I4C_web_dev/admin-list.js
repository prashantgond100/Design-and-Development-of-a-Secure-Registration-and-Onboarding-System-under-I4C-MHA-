const API = "http://localhost:5000/api/admin";
let allRegistrations = [];

if (location.pathname.includes("admin-list")) {
  const status = new URLSearchParams(location.search).get("status");

  fetch(`${API}/registrations/${status}`)
    .then(r => r.json())
    .then(d => {
      if (!d.success || !Array.isArray(d.data)) {
        const tableBody = document.getElementById("tableBody");
        tableBody.innerHTML = "<tr><td colspan='4'>No records</td></tr>";
        return;
      }
      allRegistrations = d.data;
      renderTable(allRegistrations);
    });

  // Search functionality
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  const searchCount = document.getElementById('searchCount');

  const performSearch = () => {
    const term = searchInput.value.toLowerCase().trim();
    const filtered = allRegistrations.filter(r => 
      (r.username && r.username.toLowerCase().includes(term)) ||
      (r.category && r.category.toLowerCase().includes(term)) ||
      (r.bank_fi_name && r.bank_fi_name.toLowerCase().includes(term)) ||
      (r.fi_name && r.fi_name.toLowerCase().includes(term)) ||
      (r.organization_name && r.organization_name.toLowerCase().includes(term))
    );
    renderTable(filtered);
    if (searchCount) {
      searchCount.textContent = term ? `${filtered.length} matches` : "";
    }
  };

  if (searchInput) {
    searchInput.addEventListener('input', performSearch);
    if (searchBtn) {
      searchBtn.addEventListener('click', performSearch);
    }
  }
}

function renderTable(data) {
  const tableBody = document.getElementById("tableBody");
  tableBody.innerHTML = "";
  
  data.forEach(r => {
    tableBody.innerHTML += `
      <tr>
        <td>${r.username || "-"}</td>
        <td>${r.category ? r.category.toUpperCase() : "-"}</td>
        <td>${r.onboarding_status}</td>
        <td>
          <button onclick="viewDetails(${r.id})">
            View Details
          </button>
        </td>
      </tr>
    `;
  });
}

function logout() {
  localStorage.removeItem("admin");
  location.href = "admin-login.html";
}

function viewDetails(id) {
  location.href = `admin-details.html?registrationId=${id}`;
}

function exportToCSV() {
  if (allRegistrations.length === 0) return alert("No data to export");
  
  const headers = ["User Email", "Category", "Status"];
  const rows = allRegistrations.map(r => [
    r.username || "-",
    r.category || "-",
    r.onboarding_status || "-"
  ]);

  let csvContent = "data:text/csv;charset=utf-8," 
    + headers.join(",") + "\n"
    + rows.map(e => e.join(",")).join("\n");

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `registrations_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
