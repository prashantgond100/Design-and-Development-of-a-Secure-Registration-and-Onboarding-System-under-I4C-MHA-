/* 
   NCRP FI Onboarding – Category-wise XLSX Loader
*/

document.addEventListener("DOMContentLoaded", () => {
  console.log("fi.js loaded");

  /* DOM ELEMENTS  */
  const fiCategorySelect = document.getElementById("fi_category");
  const fiDropdown = document.getElementById("fi_selector");
  const fiForm = document.getElementById("fiForm");
  const incorporationDateInput = document.getElementById("incorporation_date");
  const balanceSheetSection = document.getElementById("balanceSheetUploadSection");

  console.log("fiForm:", fiForm);

  /*  CATEGORY XLSX MAP  */
  const categoryExcelMap = {
    "Financial Market Infrastructure": "fi_list/Financial Market Infrastructure.xlsx",
    "Retail Payments Organisation": "fi_list/Retail Payments Organisation.xlsx",
    "Central Counter Parties": "fi_list/Central Counter Parties.xlsx",
    "Interoperable Mobile and Net Banking": "fi_list/Interoperable Mobile and Net Banking.xlsx",
    "BBPS Bharat Bill Payment Central Unit BBPCU": "fi_list/BBPS Bharat Bill Payment Central Unit BBPCU.xlsx",
    "BBPS Bharat Bill Payment Operating Units BBPOUs": "fi_list/BBPS Bharat Bill Payment Operating Units BBPOUs.xlsx",
    "BBPS Cards Payment Networks": "fi_list/BBPS Cards Payment Networks.xlsx",
    "BBPS Cross border Money Transfer in bound only": "fi_list/BBPS Cross border Money Transfer in-bound only.xlsx",
    "BBPS ATM Networks": "fi_list/BBPS ATM Networks.xlsx",
    "BBPS Prepaid Payment Instruments": "fi_list/BBPS Prepaid Payment Instruments.xlsx",
    "BBPS Payment Aggregators": "fi_list/BBPS Payment Aggregators.xlsx",
    "BBPS White Label ATM Operators": "fi_list/BBPS White Label ATM Operators.xlsx"
  };

  /* INITIAL STATE */
  if (fiDropdown) {
    fiDropdown.disabled = true;
    fiDropdown.innerHTML = '<option value="">Select FI category first</option>';
  }

  /*  CATEGORY CHANGE  */
  if (fiCategorySelect && fiDropdown) {
    fiCategorySelect.addEventListener("change", async () => {
      const selectedCategory = fiCategorySelect.value;

      fiDropdown.disabled = true;
      fiDropdown.innerHTML = '<option value="">Loading FIs...</option>';

      if (!categoryExcelMap[selectedCategory]) {
        fiDropdown.innerHTML = '<option value="">-- Select FI --</option>';
        return;
      }

      try {
        const response = await fetch(categoryExcelMap[selectedCategory]);
        if (!response.ok) throw new Error("Excel not found");

        const arrayBuffer = await response.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        const fiSet = new Set();
        rows.flat().forEach(cell => {
          if (typeof cell === "string" && cell.trim().length > 2) {
            fiSet.add(cleanName(cell));
          }
        });

        fiDropdown.innerHTML = '<option value="">-- Select FI --</option>';
        [...fiSet].sort().forEach(fi => {
          const option = document.createElement("option");
          option.value = fi;
          option.textContent = fi;
          fiDropdown.appendChild(option);
        });

        fiDropdown.disabled = false;

      } catch (err) {
        console.error("Excel load error:", err);
        fiDropdown.innerHTML = '<option value="">Unable to load FI list</option>';
      }
    });
  }

  /* CLEAN NAME  */
  function cleanName(name) {
    return name.replace(/\s+/g, " ").replace(/\.$/, "").trim();
  }

  /* BALANCE SHEET LOGIC */
  if (incorporationDateInput && balanceSheetSection) {
    incorporationDateInput.addEventListener("change", function () {
      while (balanceSheetSection.firstChild) {
  balanceSheetSection.removeChild(balanceSheetSection.firstChild);
}


      const incorporationDate = new Date(this.value);
      const today = new Date();
      if (isNaN(incorporationDate)) return;

      let years = today.getFullYear() - incorporationDate.getFullYear();
      if (
        today.getMonth() < incorporationDate.getMonth() ||
        (today.getMonth() === incorporationDate.getMonth() &&
          today.getDate() < incorporationDate.getDate())
      ) {
        years--;
      }

      if (years < 1) {
        balanceSheetSection.innerHTML =
          "<p><strong>No balance sheet required (FI age < 1 year).</strong></p>";
        return;
      }

      for (let i = 1; i <= Math.min(years, 3); i++) {
        const div = document.createElement("div");
        div.className = "upload-box";
        div.innerHTML = `
          <label>Balance Sheet – Year ${i}</label>
          <input type="file" name="balance_sheet_year_${i}" accept=".pdf,.xlsx" required>
        `;
        balanceSheetSection.appendChild(div);
      }
    });
  }

  /* FORM SUBMIT (FINAL & GUARANTEED) */
  if (!fiForm) return;

  fiForm.addEventListener("submit", async (e) => {
    e.preventDefault(); // 🔴 PREVENTS 405
    console.log(
  [...fiForm.querySelectorAll('input[type="file"]')].map(i => i.name)
);

    console.log("FI submit clicked");

    const storedUserId = localStorage.getItem("userId");
    if (!storedUserId) {
      alert("Session expired. Please signup again.");
      window.location.href = "signup.html";
      return;
    }

    const formData = new FormData(fiForm);
    formData.append("userId", storedUserId);

    try {
      const res = await fetch("http://localhost:5000/api/register/fi", {
        method: "POST",
        body: formData
      });

      console.log("Response status:", res.status);

      const data = await res.json();
      console.log("Response data:", data);

      if (!data.success) {
        throw new Error(data.message || "FI registration failed");
      }

      alert("FI registration successful ✅");
      window.location.href = "dashboard.html";

    } catch (err) {
      console.error("FI registration error:", err);
      alert("Error submitting FI registration ❌");
    }
  });

});
