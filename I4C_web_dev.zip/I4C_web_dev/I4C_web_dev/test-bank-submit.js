// Test script to verify bank registration with bank_fi_name field
async function testBankRegistration() {
  console.log('Testing bank registration with bank_fi_name field...');
  
  // Create a test FormData object simulating the bank registration form
  const formData = new FormData();
  formData.append('bank_category', 'SBI');
  formData.append('bank_fi_name', 'State Bank of India');
  formData.append('incorporation_date', '2026-01-01');
  formData.append('fiu_registration_id', 'test123');
  formData.append('userId', '1');
  
  try {
    const res = await fetch('http://localhost:5000/api/register/bank', {
      method: 'POST',
      body: formData
    });
    
    console.log('Response status:', res.status);
    const data = await res.json();
    console.log('Response data:', data);
    
    if (data.success) {
      console.log('✅ Test passed! Bank registration successful with bank_fi_name.');
      
      // Now test fetching the registration to verify bank_fi_name is stored
      const fetchRes = await fetch(`http://localhost:5000/api/register/registrations/by-user/1`);
      const fetchData = await fetchRes.json();
      
      if (fetchData.success && fetchData.data) {
        const formData = typeof fetchData.data.form_data === 'string' 
          ? JSON.parse(fetchData.data.form_data) 
          : fetchData.data.form_data;
        
        console.log('📋 Stored form data:', formData);
        
        if (formData.bank_fi_name === 'State Bank of India') {
          console.log('✅ Test passed! bank_fi_name is correctly stored and retrieved.');
        } else {
          console.log('❌ Test failed! bank_fi_name is not correctly stored.');
          console.log('Expected: State Bank of India, Got:', formData.bank_fi_name);
        }
      }
    } else {
      console.log('❌ Test failed! Bank registration unsuccessful.');
    }
  } catch (err) {
    console.error('❌ Test error:', err);
  }
}

testBankRegistration();