// Use relative URL to avoid CORS issues when running from different domains
const API = "http://localhost:5000/api/admin";
const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get("registrationId");

console.log("Admin Details Page Loaded");
console.log("Registration ID:", id);
console.log("API URL:", `${API}/registration/${id}`);

// Fetch registration details if ID is provided
if (id) {
  fetch(`${API}/registration/${id}`)
    .then(r => {
      console.log("Response Status:", r.status);
      if (!r.ok) {
        throw new Error(`HTTP error! status: ${r.status}`);
      }
      return r.json();
    })
    .then(d => {
      console.log("Response Data:", d);
      if (!d.success || !d.data) {
        console.log("No success or no data in response");
        return;
      }

      const reg = d.data;
      const form = typeof reg.form_data === "string" ? JSON.parse(reg.form_data) : reg.form_data || {};
      
      console.log("Registration data:", reg);
      console.log("Form data:", form);
      console.log("Category:", reg.category);

      /* ===== LEFT PANEL DATA ===== */
      
      // Helper function to set element text safely with debugging
      function setElementText(id, text) {
        const element = document.getElementById(id);
        console.log(`Setting ${id}: element found? ${!!element}, text: ${text}`);
        if (element) {
          element.innerText = text || "-";
          console.log(`${id} text set to: ${element.innerText}`);
        }
      }
      
      // Set category
      setElementText("category", reg.category);
      
      // Set sub-category (hardcoded to - as per original code)
      setElementText("subCategory", "-");
      
      // Get organization name based on registration type
      let orgName = "-";
      console.log("Form data keys:", Object.keys(form));
      if (reg.category === "bank") {
        orgName = form.bank_fi_name || "-";
        console.log("Bank orgName:", orgName);
      } else if (reg.category === "fi") {
        orgName = form.fi_name || "-";
        console.log("FI orgName:", orgName);
      } else if (reg.category === "other") {
        orgName = form.organization_name || form.other_name || "-";
        console.log("Other orgName:", orgName);
      }
      setElementText("orgName", orgName);
      
      // Set remaining fields
      setElementText("fullName", form.full_name);
      setElementText("officialEmail", form.official_email);
      setElementText("userEmail", form.user_email);
      setElementText("designation", form.designation);
      setElementText("contactNumber", form.contact_number);
      setElementText("dateIncorporation", form.incorporation_date);
      setElementText("fiuId", form.fiu_registration_id);
      setElementText("onboardingStatus", reg.onboarding_status);

      // Set existing remark if any
      const remarkInput = document.getElementById("remarkInput");
      if (remarkInput && reg.remark) {
        remarkInput.value = reg.remark;
      }

      /* ===== INITIALIZE GLOBAL ACTIONS ===== */
      const regApproveBtn = document.getElementById("regApproveBtn");
      const regRejectBtn = document.getElementById("regRejectBtn");
      const statusBadge = document.getElementById("onboardingStatus");

      if (regApproveBtn && regRejectBtn) {
        regApproveBtn.classList.remove("approved");
        regRejectBtn.classList.remove("rejected");
        
        if (reg.onboarding_status === "Approved") {
          regApproveBtn.classList.add("approved");
          statusBadge.style.background = "var(--success-color)";
          statusBadge.style.color = "white";
        } else if (reg.onboarding_status === "Rejected") {
          regRejectBtn.classList.add("rejected");
          statusBadge.style.background = "var(--danger-color)";
          statusBadge.style.color = "white";
        } else {
          statusBadge.style.background = "var(--bg-gray)";
          statusBadge.style.color = "var(--primary-color)";
        }
      }

      /* ===== RIGHT PANEL FILES ===== */
      const filesContainer = document.getElementById("files");
      const fileSearchInput = document.getElementById("fileSearchInput");
      let allFiles = [];

      const renderFiles = (filesList) => {
        filesContainer.innerHTML = "";
        if (filesList.length === 0) {
          filesContainer.innerHTML = '<div style="color: var(--text-muted); text-align: center; padding: 20px;">No documents found</div>';
          return;
        }

        filesList.forEach(f => {
          filesContainer.innerHTML += `
            <div class="file-item">
              <div class="file-info">
                <div class="file-icon">${f.file_type.charAt(0).toUpperCase()}</div>
                <div class="file-name">${f.file_type}</div>
              </div>
              <a href="#" class="view-file-btn" onclick="openFile(${f.id})">VIEW DOC</a>
            </div>
          `;
        });
      };

      allFiles = Array.isArray(reg.files) ? reg.files.filter(f => f && f.file_type) : [];
      renderFiles(allFiles);

      if (fileSearchInput) {
        fileSearchInput.addEventListener("input", (e) => {
          const term = e.target.value.toLowerCase().trim();
          const filtered = allFiles.filter(f => 
            f.file_type && f.file_type.toLowerCase().includes(term)
          );
          renderFiles(filtered);
        });
      }
    })
    .catch(err => {
      console.error("Error fetching admin details:", err);
      // Display error message to user
      const errorMsg = `Error loading details: ${err.message}`;
      console.error(errorMsg);
    });
}

/* ===== FILE VIEW ===== */
function openFile(fileId) {
  window.open(`${API}/file/view/${fileId}`, "_blank");
}

/* ===== FILE STATUS UPDATE (ONLY ONE ACTIVE AT A TIME) ===== */
function updateFile(fileId, status, btn) {
  const actionCell = btn.parentElement;
  const approveBtn = actionCell.querySelector(".approve-btn");
  const rejectBtn = actionCell.querySelector(".reject-btn");

  fetch(`${API}/file/${fileId}/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status })
  })
    .then(() => {
      // Reset both buttons
      approveBtn.classList.remove("approved");
      rejectBtn.classList.remove("rejected");

      // Activate only the selected one
      if (status === "Approved") {
        approveBtn.classList.add("approved");
      } else if (status === "Rejected") {
        rejectBtn.classList.add("rejected");
      }
    })
    .catch(err => console.error("Status update error:", err));
}

/* ===== GLOBAL REGISTRATION STATUS (APPROVE/REJECT) ===== */
function logout() {
  localStorage.removeItem("admin");
  location.href = "admin-login.html";
}

function toggleRegistrationStatus(targetStatus) {
  const id = new URLSearchParams(location.search).get("registrationId");
  const approveBtn = document.getElementById("regApproveBtn");
  const rejectBtn = document.getElementById("regRejectBtn");
  const statusDisplay = document.getElementById("onboardingStatus");

  // Determine current active state
  const approveActive = approveBtn.classList.contains("approved");
  const rejectActive = rejectBtn.classList.contains("rejected");

  // Toggle logic: clicking active returns to Under Process (or Pending)
  let newStatus = targetStatus;
  if (targetStatus === "Approved" && approveActive) {
    newStatus = "Under Process";
  } else if (targetStatus === "Rejected" && rejectActive) {
    newStatus = "Under Process";
  }

  // Confirm for final onboarding actions
  if (newStatus === "Approved" || newStatus === "Rejected") {
    const verb = newStatus.toLowerCase();
    const ok = confirm(`Are you sure you want to ${verb} this registration for onboarding?`);
    if (!ok) return;
  }

  // --- OPTIMISTIC UI UPDATE (RAPID RESPONSE) ---
  const oldStatusText = statusDisplay.innerText;
  const oldApproveClass = approveBtn.classList.contains("approved");
  const oldRejectClass = rejectBtn.classList.contains("rejected");

  // Apply immediate visual changes
  statusDisplay.innerText = newStatus;
  approveBtn.classList.remove("approved");
  rejectBtn.classList.remove("rejected");
  if (newStatus === "Approved") {
    approveBtn.classList.add("approved");
    statusDisplay.style.background = "var(--success-color)";
    statusDisplay.style.color = "white";
  } else if (newStatus === "Rejected") {
    rejectBtn.classList.add("rejected");
    statusDisplay.style.background = "var(--danger-color)";
    statusDisplay.style.color = "white";
  } else {
    statusDisplay.style.background = "var(--bg-gray)";
    statusDisplay.style.color = "var(--primary-color)";
  }

  // Send request in background
  fetch(`${API}/registration/${id}/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: newStatus })
  })
    .then(r => r.json())
    .then(d => {
      if (!d.success) {
        // Revert on failure
        statusDisplay.innerText = oldStatusText;
        approveBtn.classList.toggle("approved", oldApproveClass);
        rejectBtn.classList.toggle("rejected", oldRejectClass);
        alert("Failed to update registration status. Please try again.");
      }
      // No alert on success for "rapid response"
    })
    .catch(err => {
      console.error("Registration status update error:", err);
      // Revert on error
      statusDisplay.innerText = oldStatusText;
      approveBtn.classList.toggle("approved", oldApproveClass);
      rejectBtn.classList.toggle("rejected", oldRejectClass);
      alert("Error updating status. Connection lost?");
    });
}

/* ===== SEND REMARK TO USER ===== */
function sendRemark() {
  const id = new URLSearchParams(location.search).get("registrationId");
  const remark = document.getElementById("remarkInput").value;
  if (!remark || !remark.trim()) return alert("Please enter a remark first.");

  fetch(`${API}/registration/${id}/remark`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ remark: remark.trim() })
  })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        alert("Remark sent successfully to user dashboard.");
        document.getElementById("remarkInput").value = "";
      } else {
        alert("Failed to send remark.");
      }
    })
    .catch(err => {
      console.error("Remark send error:", err);
      alert("Error sending remark.");
    });
}
