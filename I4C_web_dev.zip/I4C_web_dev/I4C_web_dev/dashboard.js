document.addEventListener("DOMContentLoaded", () => {

  /* ================= SESSION ================= */
  const userId = localStorage.getItem("userId");
  const username = localStorage.getItem("username");

  if (!userId) {
    alert("Session expired. Please login again.");
    localStorage.clear();
    window.location.href = "login.html";
    return;
  }

  /* ================= SHOW USER ================= */
  const usernameEl = document.getElementById("username");
  if (usernameEl) {
    const labelValue = username ? `User ID: ${username}` : `User ID: ${userId}`;
    usernameEl.innerText = labelValue;
  }

  /* ================= CHECK STATUS ================= */
  const checkBtn = document.getElementById("checkStatusBtn");
  if (checkBtn) {
    checkBtn.addEventListener("click", async () => {
      const card = document.getElementById("statusCard");
      if (!card) return;

      card.style.display = "block";
      card.innerHTML = "Loading latest status...";

      const reg = await fetchLatestRegistration(userId);

      if (!reg) {
        card.innerHTML = `
<pre>
---------------------------------------------
 Registration Status
---------------------------------------------
 No registration found yet.
 Please complete registration first.
---------------------------------------------
</pre>`;
        return;
      }

      renderStatusCard(reg);
    });
  }

  /* ================= LOGOUT ================= */
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.clear();
      alert("Logged out successfully");
      window.location.href = "login.html";
    });
  }
});

/* ================================================= */
/* ===== ALWAYS FETCH LATEST REGISTRATION =========== */
/* ================================================= */
async function fetchLatestRegistration(userId) {
  try {
    const res = await fetch(
  `http://localhost:5000/api/register/registrations/by-user/${userId}`
);


    if (!res.ok) throw new Error("Fetch failed");

    const result = await res.json();

    if (!result.success || !result.data) {
      return null;
    }

    return result.data;

  } catch (err) {
    console.error("Dashboard fetch error:", err);
    return null;
  }
}

/* ================= HELPERS ================= */
function hasFile(files, keyword) {
  if (!Array.isArray(files)) return false;
  return files.some(
    f =>
      f.file_type &&
      f.file_type.toLowerCase().includes(keyword.toLowerCase())
  );
}

/* ================= RENDER ================= */
function renderStatusCard(reg) {
  const card = document.getElementById("statusCard");
  if (!card) return;

  // Parse form_data from backend (string or object)
  let form = {};
  try {
    form =
      typeof reg.form_data === "string"
        ? JSON.parse(reg.form_data || "{}")
        : (reg.form_data || {});
  } catch (_) {
    form = {};
  }

  const files = reg.files || [];
  const submittedDate = reg.created_at
    ? new Date(reg.created_at).toDateString()
    : "N/A";

  const onboardingStatus = reg.onboarding_status || "Pending";
  const details = {
    full_name: form.full_name || "N/A",
    official_email: form.official_email || "N/A",
    user_email: form.user_email || "N/A",
    designation: form.designation || "N/A",
    contact_number: form.contact_number || "N/A",
    userId: localStorage.getItem("username") || localStorage.getItem("userId") || "N/A",
    incorporation_date: form.incorporation_date || "N/A",
    fiu_registration_id: form.fiu_registration_id || "N/A"
  };

  // dynamic labels/values by registration category
  const cat = (reg.category || "").toLowerCase();
  let categoryLabel = "FI Category";
  let nameLabel = "FI Name";
  let categoryValue = form.fi_category || "N/A";
  let nameValue = form.fi_name || "N/A";

  if (cat === "bank") {
    categoryLabel = "Bank Category";
    nameLabel = "Bank Name";
    categoryValue = form.bank_category || "N/A";
    nameValue = form.bank_fi_name || "N/A";
  } else if (cat === "other") {
    categoryLabel = "Other Category";
    nameLabel = "Other Name";
    categoryValue = form.other_category || "N/A";
    nameValue = form.organization_name || form.other_name || "N/A";
  }

  card.innerHTML = `
<pre style="
  font-size: 18px;
  line-height: 1.7;
  font-family: Consolas, 'Courier New', monospace;
">
---------------------------------------------
 Registration Summary
---------------------------------------------
 Category            : ${reg.category.toUpperCase()}
 Submitted On        : ${submittedDate}
 Submission Status   : Submitted
 Onboarding Status   : ${onboardingStatus}
---------------------------------------------
 User Details
 ---------------------------------------------
 Full Name           : ${details.full_name}
 Official Email      : ${details.official_email}
 User Email          : ${details.user_email}
 Designation         : ${details.designation}
 Contact Number      : ${details.contact_number}
 User ID             : ${details.userId}
 ${categoryLabel.padEnd(19," ")}: ${categoryValue}
 ${nameLabel.padEnd(19," ")}: ${nameValue}
 Incorporation Date  : ${details.incorporation_date}
 FIU Registration ID : ${details.fiu_registration_id}
 ---------------------------------------------
 Documents Uploaded
---------------------------------------------
 ${hasFile(files,"rbi") ? "✔" : "✖"} RBI Certificate
 ${hasFile(files,"gst") ? "✔" : "✖"} GST Certificate
 ${hasFile(files,"fiu") ? "✔" : "✖"} FIU Screenshot
 ${hasFile(files,"balance_sheet_year_1") ? "✔" : "✖"} Balance Sheet Year 1
 ${hasFile(files,"balance_sheet_year_2") ? "✔" : "✖"} Balance Sheet Year 2
 ${hasFile(files,"balance_sheet_year_3") ? "✔" : "✖"} Balance Sheet Year 3
 ${hasFile(files,"nodal") ? "✔" : "✖"} Nodal Officer Sheet
 ${hasFile(files,"terms") ? "✔" : "✖"} Terms & Conditions
---------------------------------------------
</pre>
`;
}
