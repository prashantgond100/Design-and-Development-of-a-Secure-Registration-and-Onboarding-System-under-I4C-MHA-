document.addEventListener("DOMContentLoaded", () => {
  const bankForm = document.getElementById("bankForm");
  if (!bankForm) return;

  bankForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    console.log("Bank form submit clicked");
    
    const storedUserId = localStorage.getItem("userId");
    if (!storedUserId) {
      alert("Session expired. Please signup again.");
      window.location.href = "user%20register.html";
      return;
    }

    const formData = new FormData(bankForm);
    formData.append("userId", storedUserId);

    try {
      const res = await fetch("http://localhost:5000/api/register/bank", {
        method: "POST",
        body: formData
      });

      console.log("Response status:", res.status);
      
      const data = await res.json();
      console.log("Response data:", data);

      if (!data.success) {
        throw new Error(data.message || "Bank registration failed");
      }

      alert("Bank registration successful ✅");
      window.location.href = "dashboard.html";

    } catch (err) {
      console.error("Bank registration error:", err);
      alert("Error submitting Bank registration ❌");
    }
  });
});