const regId = new URLSearchParams(window.location.search)
  .get("registrationId");

fetch(`http://127.0.0.1:5000/api/admin/registration/${regId}`)
  .then(res => res.json())
  .then(result => {
    const d = result.data;

    // LEFT SIDE
    document.getElementById("username").innerText = d.username;
    document.getElementById("category").innerText = d.category;

    const form = d.form_data;
    document.getElementById("email").innerText = form.official_email;
    document.getElementById("contact").innerText = form.contact_number;

    // RIGHT SIDE (FILES)
    const filesDiv = document.getElementById("files");
    filesDiv.innerHTML = "";

    d.files.forEach(f => {
      if (!f) return;
      const div = document.createElement("div");
      div.innerHTML = `
        ${f.file_type}
        <button onclick="openFile(${f.id})">View</button>
      `;
      filesDiv.appendChild(div);
    });
  });

function openFile(fileId) {
  window.open(
    `http://127.0.0.1:5000/api/admin/file/${fileId}`,
    "_blank"
  );
}
