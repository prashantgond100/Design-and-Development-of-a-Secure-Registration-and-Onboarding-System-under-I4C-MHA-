document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("bankForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = {
      full_name: form.full_name.value.trim(),
      official_email: form.official_email.value.trim(),
      user_email: form.user_email.value.trim(),
      designation: form.designation.value.trim(),
      contact_number: form.contact_number.value.trim(),
      userId: form.userId.value.trim(),
      password: form.password.value.trim()
    };

    // basic validation
    for (let key in payload) {
      if (!payload[key]) {
        alert(`Missing field: ${key}`);
        return;
      }
    }

    try {
      const res = await fetch("http://localhost:5000/api/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const contentType = res.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        const text = await res.text();
        console.error("Non-JSON response received:", text);
        throw new Error(`Server returned non-JSON response (${res.status}). Check backend logs.`);
      }

      const data = await res.json();

      if (!res.ok || !data.success) {
        alert(data.message || "Signup failed");
        return;
      }

      localStorage.setItem("userId", data.userId);

      alert("Signup successful ✅");
      window.location.href = "home.html";

    } catch (err) {
      console.error("Signup error:", err);
      alert(`Error during signup: ${err.message}`);
    }
  });
});
