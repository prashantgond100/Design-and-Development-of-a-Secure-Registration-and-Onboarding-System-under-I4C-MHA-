const API = "http://localhost:5000/api/admin";
const id = 7;

fetch(`${API}/registration/${id}`)
  .then(r => r.json())
  .then(d => {
    console.log(JSON.stringify(d, null, 2));
  })
  .catch(err => console.error(err));
