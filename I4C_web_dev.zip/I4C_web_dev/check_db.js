const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "8001354567@Pg",
  database: "ncrp_db"
});

db.connect(err => {
  if (err) {
    console.error("❌ MySQL connection error:", err.message);
    process.exit(1);
  }
  console.log("✅ MySQL connected");

  db.query("SHOW TABLES", (err, rows) => {
    if (err) {
      console.error("❌ Error showing tables:", err.message);
      process.exit(1);
    }
    console.log("Tables in database:", rows.map(r => Object.values(r)[0]));

    const tables = ["users", "registrations", "files"];
    tables.forEach(table => {
      db.query(`DESCRIBE ${table}`, (err, cols) => {
        if (err) {
          console.error(`❌ Table '${table}' missing or error:`, err.message);
        } else {
          console.log(`✅ Table '${table}' exists. Columns:`, cols.map(c => c.Field).join(", "));
        }
        if (table === tables[tables.length - 1]) {
          db.end();
        }
      });
    });
  });
});
