const express = require("express");
const router = express.Router();
const multer = require("multer");
const db = require("./db");

/* ================= MULTER CONFIG ================= */
const upload = multer({ storage: multer.memoryStorage() });

const commonUpload = upload.fields([
  { name: "rbi_certificate", maxCount: 1 },
  { name: "gst_certificate", maxCount: 1 },
  { name: "fiu_screenshot", maxCount: 1 },
  { name: "nodal_officer_sheet", maxCount: 1 },
  { name: "terms_conditions", maxCount: 1 },
  { name: "balance_sheet_year_1", maxCount: 1 },
  { name: "balance_sheet_year_2", maxCount: 1 },
  { name: "balance_sheet_year_3", maxCount: 1 }
]);

/* ================= COMMON HANDLER ================= */
const handleRegistration = (category) => (req, res) => {
  db.beginTransaction((transactionErr) => {
    if (transactionErr) {
      console.error("❌ Transaction start error:", transactionErr);
      return res.status(500).json({ success: false });
    }

    try {
      console.log(`✅ REGISTER HIT: ${category}`);
      const bodyData = { ...req.body };
      
      let signupData = null;
      if (bodyData.signupData) {
        try {
          signupData = JSON.parse(bodyData.signupData);
          delete bodyData.signupData;
        } catch (e) {
          console.error("❌ Failed to parse signupData");
        }
      }

      const userId = bodyData.userId; 
      delete bodyData.userId;

      /* ================= UTIL: SAFE JSON PARSE ================= */
      const parseDbJson = (raw) => {
        if (!raw) return {};
        if (typeof raw === "object") return raw;
        if (typeof raw === "string") {
          const s = raw.trim();
          if (s === "" || s === "[object Object]") return {};
          try { return JSON.parse(s); } catch { return {}; }
        }
        return {};
      };

      const proceedWithRegistration = (finalUserId, finalUsername, signupForm = {}) => {
        const checkSql = "SELECT * FROM registrations WHERE user_id = ? LIMIT 1";

        db.query(checkSql, [finalUserId], (checkErr, rows) => {
          if (checkErr) {
            console.error("❌ Check registration error:", checkErr);
            return db.rollback(() => res.status(500).json({ success: false }));
          }

          let registrationId;
          let finalFormData = { ...signupForm, ...bodyData };

          const proceedWithFiles = (regId) => {
            const files = req.files || {};
            const fileInserts = [];
            for (const key in files) {
              const file = files[key][0];
              fileInserts.push([regId, file.originalname, key, file.buffer, "Pending"]);
            }

            if (fileInserts.length === 0) {
              return db.commit((commitErr) => {
                if (commitErr) return db.rollback(() => res.status(500).json({ success: false }));
                res.json({ success: true, userId: finalUserId, username: finalUsername });
              });
            }

            const insertFiles = "INSERT INTO files (registration_id, file_name, file_type, file_data, status) VALUES ?";
            db.query(insertFiles, [fileInserts], (err2) => {
              if (err2) {
                console.error("❌ File insert error:", err2);
                return db.rollback(() => res.status(500).json({ success: false }));
              }
              db.commit((commitErr) => {
                if (commitErr) return db.rollback(() => res.status(500).json({ success: false }));
                res.json({ success: true, userId: finalUserId, username: finalUsername });
              });
            });
          };

          if (rows.length > 0) {
            const existingRow = rows[0];
            registrationId = existingRow.id;
            const existingFormData = parseDbJson(existingRow.form_data);
            finalFormData = { ...signupForm, ...existingFormData, ...bodyData };

            const updateSql = "UPDATE registrations SET category = ?, form_data = ?, onboarding_status = 'Pending' WHERE id = ?";
            db.query(updateSql, [category, JSON.stringify(finalFormData), registrationId], (updErr) => {
              if (updErr) {
                console.error("❌ Update error:", updErr);
                return db.rollback(() => res.status(500).json({ success: false }));
              }
              proceedWithFiles(registrationId);
            });
          } else {
            const insertSql = "INSERT INTO registrations (user_id, category, form_data, onboarding_status) VALUES (?, ?, ?, 'Pending')";
            db.query(insertSql, [finalUserId, category, JSON.stringify(finalFormData)], (insErr, result) => {
              if (insErr) {
                console.error("❌ Insert error:", insErr);
                return db.rollback(() => res.status(500).json({ success: false }));
              }
              proceedWithFiles(result.insertId);
            });
          }
        });
      };

      if (signupData) {
        // 1️⃣ CREATE USER FIRST
        const userSql = "INSERT INTO users (user_id, password) VALUES (?, ?)";
        db.query(userSql, [signupData.userId, signupData.password], (userErr, userResult) => {
          if (userErr) {
            console.error("❌ User creation error:", userErr);
            return db.rollback(() => res.status(400).json({ success: false, message: "User already exists" }));
          }

          const newUserId = userResult.insertId;
          const signupForm = {
            full_name: signupData.full_name,
            official_email: signupData.official_email,
            user_email: signupData.user_email,
            designation: signupData.designation,
            contact_number: signupData.contact_number
          };

          proceedWithRegistration(newUserId, signupData.userId, signupForm);
        });
      } else {
        // EXISTING USER
        const numericUserId = Number(userId);
        if (!numericUserId || Number.isNaN(numericUserId)) {
          return db.rollback(() => res.status(400).json({ success: false, message: "Invalid user session" }));
        }

        const userFetchSql = "SELECT user_id FROM users WHERE id = ?";
        db.query(userFetchSql, [numericUserId], (uFetchErr, uRows) => {
          if (uFetchErr || !uRows.length) {
            console.error("❌ User fetch error:", uFetchErr);
            return db.rollback(() => res.status(404).json({ success: false, message: "User not found" }));
          }
          const finalUsername = uRows[0].user_id;

          const signupSql = "SELECT form_data FROM registrations WHERE user_id = ? AND category IN ('signup','bank') ORDER BY created_at DESC LIMIT 1";
          db.query(signupSql, [numericUserId], (signupErr, signupRows) => {
            const rawSignup = signupRows && signupRows.length ? signupRows[0].form_data : "{}";
            const signupForm = parseDbJson(rawSignup);
            proceedWithRegistration(numericUserId, finalUsername, signupForm);
          });
        });
      }

    } catch (err) {
      console.error(`❌ ${category} registration error:`, err);
      db.rollback(() => res.status(500).json({ success: false }));
    }
  });
};

/* ================= ROUTES ================= */
router.post("/bank", commonUpload, handleRegistration("bank"));
router.post("/fi", commonUpload, handleRegistration("fi"));
router.post("/other", commonUpload, handleRegistration("other"));

/* ================= GET REGISTRATION BY USER ================= */
router.get("/registrations/by-user/:userId", (req, res) => {
  const userId = req.params.userId;

  // Helper to safely parse JSON/string/object payloads
  const parseSafe = (raw) => {
    if (!raw) return {};
    if (typeof raw === "object") return raw;
    if (typeof raw === "string") {
      if (raw.trim() === "[object Object]") return {};
      try { return JSON.parse(raw); } catch { return {}; }
    }
    return {};
  };

  const latestSql = `
    SELECT r.*, u.user_id AS username,
    JSON_ARRAYAGG(
      JSON_OBJECT(
        'id', f.id,
        'file_type', f.file_type,
        'file_name', f.file_name,
        'status', f.status
      )
    ) AS files
    FROM registrations r
    JOIN users u ON r.user_id = u.id
    LEFT JOIN files f ON r.id = f.registration_id
    WHERE r.user_id = ?
    GROUP BY r.id
    ORDER BY r.created_at DESC
    LIMIT 1
  `;

  db.query(latestSql, [userId], (err, latestRows) => {
    if (err) {
      console.error("Fetch registration error:", err);
      return res.status(500).json({ success: false });
    }

    const latest = latestRows && latestRows.length ? latestRows[0] : null;

    // Fetch the string user_id (username) regardless of whether a registration exists
    const userSql = "SELECT user_id FROM users WHERE id = ?";
    db.query(userSql, [userId], (uErr, uRows) => {
      const stringUserId = (uRows && uRows.length) ? uRows[0].user_id : null;

      const signupSql = `
        SELECT form_data 
        FROM registrations 
        WHERE user_id = ? AND category IN ('signup','bank')
        ORDER BY created_at DESC
        LIMIT 1
      `;

      db.query(signupSql, [userId], (err2, signupRows) => {
        if (err2) {
          console.error("Fetch signup form_data error:", err2);
          // Even if signup fetch fails, still return latest
          return res.json({ success: true, data: latest, username: stringUserId });
        }

        const signupForm = signupRows && signupRows.length ? parseSafe(signupRows[0].form_data) : {};
        if (!latest) {
          // No registration yet, but maybe signup exists
          return res.json({
            success: true,
            username: stringUserId,
            data: signupRows && signupRows.length ? {
              user_id: Number(userId),
              username: stringUserId,
              category: "signup",
              form_data: signupForm,
              files: []
            } : null
          });
        }

        const latestForm = parseSafe(latest.form_data);
        const merged = { ...signupForm, ...latestForm };
        // Return merged form_data to the client
        latest.form_data = merged;
        latest.username = stringUserId; // Ensure username is present in data object too

        // Aggregate admin remarks across all registrations for this user
        const allSql = "SELECT form_data FROM registrations WHERE user_id = ?";
        db.query(allSql, [userId], (err3, allRows) => {
          if (!err3 && Array.isArray(allRows)) {
            const remarks = [];
            allRows.forEach(r => {
              const fd = parseSafe(r.form_data);
              if (Array.isArray(fd.admin_remarks)) {
                remarks.push(...fd.admin_remarks);
              }
            });
            if (remarks.length) {
              latest.form_data.admin_remarks = remarks;
            }
          }
          return res.json({ success: true, data: latest, username: stringUserId });
        });
      });
    });
  });
});

module.exports = router;
