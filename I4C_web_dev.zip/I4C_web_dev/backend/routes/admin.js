const express = require("express");
const router = express.Router();
const db = require("./db");

/* ================= UTIL: SAFE JSON PARSE ================= */
function parseJson(raw) {
  if (!raw) return {};
  if (typeof raw === "object") return raw;
  if (typeof raw === "string") {
    const s = raw.trim();
    if (!s || s === "[object Object]") return {};
    try { return JSON.parse(s); } catch { return {}; }
  }
  return {};
}

/* ================= ADMIN LOGIN ================= */
router.post("/login", (req, res) => {
  const { username, password } = req.body;

  db.query(
    "SELECT * FROM admins WHERE username=? AND password=?",
    [username, password],
    (err, rows) => {
      if (err) return res.status(500).json({ success: false });
      if (!rows.length)
        return res.json({ success: false, message: "Invalid credentials" });

      res.json({
        success: true,
        admin: { id: rows[0].id, username: rows[0].username }
      });
    }
  );
});

/* ================= LIST BY STATUS ================= */
router.get("/registrations/:status", (req, res) => {
  const status = req.params.status;
  let sql = `
    SELECT 
      r.id,
      r.category,
      r.onboarding_status,
      JSON_UNQUOTE(JSON_EXTRACT(r.form_data, '$.user_email')) AS username,
      JSON_UNQUOTE(JSON_EXTRACT(r.form_data, '$.bank_fi_name')) AS bank_fi_name,
      JSON_UNQUOTE(JSON_EXTRACT(r.form_data, '$.fi_name')) AS fi_name,
      JSON_UNQUOTE(JSON_EXTRACT(r.form_data, '$.organization_name')) AS organization_name,
      JSON_UNQUOTE(JSON_EXTRACT(r.form_data, '$.sub_category')) AS sub_category
    FROM registrations r
    WHERE `;

  const params = [];
  if (status === "Completed") {
    sql += "r.onboarding_status IN ('Approved','Rejected','Completed')";
  } else {
    sql += "r.onboarding_status = ?";
    params.push(status);
  }
  sql += " ORDER BY r.created_at DESC";

  db.query(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true, data: rows });
  });
});

/* ================= DETAILS ================= */
router.get("/registration/:id", (req, res) => {
  const id = req.params.id;

  const sql = `
    SELECT r.*,
    JSON_ARRAYAGG(
      JSON_OBJECT(
        'id', f.id,
        'file_type', f.file_type,
        'file_name', f.file_name,
        'status', f.status
      )
    ) AS files
    FROM registrations r
    LEFT JOIN files f ON r.id = f.registration_id
    WHERE r.id = ?
    GROUP BY r.id
  `;

  db.query(sql, [id], (err, rows) => {
    if (err || !rows.length)
      return res.status(404).json({ success: false });

    res.json({ success: true, data: rows[0] });
  });
});

/* ================= VIEW FILE ================= */
router.get("/file/view/:id", (req, res) => {
  const fileId = req.params.id;
  // Find registration_id for this file and mark as Under Process
  db.query("SELECT registration_id, file_name, file_data FROM files WHERE id=?", [fileId], (err, rows) => {
    if (err || !rows.length) return res.sendStatus(404);
    const regId = rows[0].registration_id;
    // Update registration status to Under Process (non-blocking)
    db.query("UPDATE registrations SET onboarding_status='Under Process' WHERE id=?", [regId], () => {
      res.setHeader("Content-Disposition", `inline; filename="${rows[0].file_name}"`);
      res.send(rows[0].file_data);
    });
  });
});

/* ================= UPDATE FILE STATUS ================= */
router.post("/file/:id/status", (req, res) => {
  const { status } = req.body; // 'Approved' | 'Rejected' | 'Pending'
  const fileId = req.params.id;
  console.log("Updating file:", fileId, status);

  // 1️⃣ Update file status
  db.query("UPDATE files SET status=? WHERE id=?", [status, fileId], (err) => {
    if (err) {
      console.error(err);
      return res.json({ success: false });
    }
    // 2️⃣ Propagate to registration status only for final verdicts
    db.query("SELECT registration_id FROM files WHERE id=?", [fileId], (err2, rows) => {
      if (err2 || rows.length === 0) {
        return res.json({ success: true });
      }
      const regId = rows[0].registration_id;
      if (status === "Approved" || status === "Rejected") {
        db.query("UPDATE registrations SET onboarding_status=? WHERE id=?", [status, regId], (err3) => {
          if (err3) console.error(err3);
          return res.json({ success: true });
        });
      } else {
        // 'Pending' does not change registration status
        return res.json({ success: true });
      }
    });
  });
});

/* ================= ADD REGISTRATION REMARK ================= */
router.post("/registration/:id/remark", (req, res) => {
  const regId = req.params.id;
  const { file_id, remark } = req.body;
  if (!remark || typeof remark !== "string") {
    return res.json({ success: false, message: "Remark required" });
  }

  db.query("SELECT form_data FROM registrations WHERE id=?", [regId], (err, rows) => {
    if (err || !rows.length) return res.json({ success: false });
    const form = parseJson(rows[0].form_data);
    if (!Array.isArray(form.admin_remarks)) form.admin_remarks = [];
    form.admin_remarks.push({
      file_id: file_id || null,
      remark,
      at: new Date().toISOString()
    });
    db.query("UPDATE registrations SET form_data=? WHERE id=?", [JSON.stringify(form), regId], (err2) => {
      if (err2) return res.json({ success: false });
      return res.json({ success: true });
    });
  });
});


/* ================= UPDATE REGISTRATION STATUS ================= */
router.post("/registration/:id/status", (req, res) => {
  const { status } = req.body;

  db.query(
    "UPDATE registrations SET onboarding_status=? WHERE id=?",
    [status, req.params.id],
    () => res.json({ success: true })
  );
});

/* ================= GET STATS ================= */
router.get("/stats", (req, res) => {
  const sql = `
    SELECT 
      onboarding_status as status, 
      COUNT(*) as count 
    FROM registrations 
    GROUP BY onboarding_status
  `;
  db.query(sql, (err, rows) => {
    if (err) return res.status(500).json({ success: false });
    res.json({ success: true, data: rows });
  });
});

module.exports = router;
