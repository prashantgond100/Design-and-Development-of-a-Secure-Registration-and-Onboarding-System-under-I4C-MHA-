const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "8001354567@Pg",
  database: "ncrp_db"
});

db.connect(err => {
  if (err) {
    console.error("Connection failed:", err);
    process.exit(1);
  }
  console.log("Connected to DB");

  // 1. Check current schema
  db.query("DESCRIBE registrations", (err, rows) => {
    if (err) {
      console.error("Error describing table:", err);
      process.exit(1);
    }
    
    const categoryCol = rows.find(r => r.Field === 'category');
    console.log("Current category column:", categoryCol);

    // 2. Modify column
    console.log("Modifying category column to VARCHAR(50)...");
    const alterSql = "ALTER TABLE registrations MODIFY COLUMN category VARCHAR(50)";
    
    db.query(alterSql, (err2) => {
      if (err2) {
        console.error("Error altering table:", err2);
        // If it fails, maybe it's not an ENUM but something else?
        // But let's see.
      } else {
        console.log("Table altered successfully ✅");
      }

      // 3. Verify
      db.query("DESCRIBE registrations", (err3, rows3) => {
        const newCategoryCol = rows3.find(r => r.Field === 'category');
        console.log("New category column:", newCategoryCol);
        db.end();
      });
    });
  });
});
