document.addEventListener("DOMContentLoaded", () => {

  const form = document.getElementById("otherForm");
  const incorporationDateInput = document.getElementById("incorporation_date");
  const balanceSheetSection = document.getElementById("balanceSheetUploadSection");
  const params = new URLSearchParams(location.search);
  const isEdit = params.get("edit") === "1";

  const otherSearch = document.getElementById("other_search");
  const otherOptionsContainer = document.getElementById("other_options");
  const otherHiddenInput = document.getElementById("other_selector");

  if (otherSearch) {
    otherSearch.addEventListener("input", () => {
      const val = otherSearch.value;
      otherHiddenInput.value = val;
      
      // For "Other", we might not have a list, but we can show the current value
      if (val.trim().length > 0) {
        otherOptionsContainer.innerHTML = `<div class="select-option">${val}</div>`;
        otherOptionsContainer.style.display = "block";
        
        const option = otherOptionsContainer.querySelector(".select-option");
        option.addEventListener("click", () => {
          otherSearch.value = val;
          otherHiddenInput.value = val;
          otherOptionsContainer.style.display = "none";
        });
      } else {
        otherOptionsContainer.style.display = "none";
      }
    });

    otherSearch.addEventListener("focus", () => {
      if (otherSearch.value.trim().length > 0) {
        otherOptionsContainer.style.display = "block";
      }
    });

    document.addEventListener("click", (e) => {
      if (!e.target.closest(".searchable-select")) {
        otherOptionsContainer.style.display = "none";
      }
    });
  }

  if (incorporationDateInput && balanceSheetSection) {
    incorporationDateInput.addEventListener("change", function () {
      while (balanceSheetSection.firstChild) {
  balanceSheetSection.removeChild(balanceSheetSection.firstChild);
}


      const incorporationDate = new Date(this.value);
      const today = new Date();
      if (isNaN(incorporationDate)) return;

      let years = today.getFullYear() - incorporationDate.getFullYear();
      const monthDiff = today.getMonth() - incorporationDate.getMonth();

      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < incorporationDate.getDate())) {
        years--;
      }

      if (years < 1) {
        balanceSheetSection.innerHTML =
          "<p><strong>No balance sheet required (Entity age < 1 year).</strong></p>";
        return;
      }

      for (let i = 1; i <= Math.min(years, 3); i++) {
        const div = document.createElement("div");
        div.className = "upload-box";
        div.innerHTML = `
          <label>Balance Sheet – Year ${i}</label>
          <input type="file" name="balance_sheet_year_${i}" required>
        `;
        balanceSheetSection.appendChild(div);
      }
      if (isEdit) {
        const bsInputs = balanceSheetSection.querySelectorAll('input[type="file"]');
        bsInputs.forEach(inp => { inp.required = false; });
      }
    });
  }

  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const userId = localStorage.getItem("userId");
      const signupData = localStorage.getItem("signupData");

      const formData = new FormData(form);

      if (userId) {
        formData.append("userId", userId);
      } else if (signupData) {
        formData.append("signupData", signupData);
      } else {
        alert("Session expired. Please signup again.");
        window.location.href = "signup.html";
        return;
      }

      try {
        const res = await fetch("http://localhost:5000/api/register/other", {
          method: "POST",
          body: formData
        });

        const data = await res.json();
        if (!data.success) throw new Error(data.message || "Registration failed");

        // ✅ Store the new userId, username and clear signup data
        if (data.userId) {
          localStorage.setItem("userId", data.userId);
        }
        if (data.username) {
          localStorage.setItem("username", data.username);
        }
        localStorage.removeItem("signupData");

        alert("Other entity registration successful ✅");
        
        window.location.href = "dashboard.html";

      } catch (err) {
        console.error(err);
        alert(`Error submitting Other registration: ${err.message}`);
      }
    });
  }

  async function prefillFromLatest() {
    try {
      const userId = localStorage.getItem("userId");
      if (!userId) return;
      const res = await fetch(`http://localhost:5000/api/register/registrations/by-user/${userId}`);
      if (!res.ok) return;
      const result = await res.json();
      if (!result.success || !result.data) return;
      const reg = result.data;
      const formData = typeof reg.form_data === "string" ? JSON.parse(reg.form_data || "{}") : (reg.form_data || {});

      const catSel = document.getElementById("other_category");
      if (catSel && formData.other_category) catSel.value = formData.other_category;
      
      if (otherSearch && formData.organization_name) {
        otherSearch.value = formData.organization_name;
        otherHiddenInput.value = formData.organization_name;
      }

      if (incorporationDateInput && formData.incorporation_date) {
        incorporationDateInput.value = formData.incorporation_date;
        incorporationDateInput.dispatchEvent(new Event("change"));
      }
      const fiu = document.querySelector('[name="fiu_registration_id"]');
      if (fiu && formData.fiu_registration_id) fiu.value = formData.fiu_registration_id;

      const fileInputs = document.querySelectorAll('#otherForm input[type="file"]');
      fileInputs.forEach(inp => { inp.required = false; });
    } catch {}
  }

  if (isEdit) {
    prefillFromLatest();
  }
});
