const API = "http://127.0.0.1:5000/api/admin";
const tableBody = document.getElementById("tableBody");
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const searchCount = document.getElementById("searchCount");
let currentRows = [];

function logout() {
  localStorage.removeItem("adminId");
  localStorage.removeItem("adminUsername");
  localStorage.removeItem("admin");
  location.href = "admin-login.html";
}

function displayName(r) {
  return r.bank_fi_name || r.fi_name || r.organization_name || "-";
}

function renderRows(rows) {
  tableBody.innerHTML = "";
  if (!rows.length) {
    tableBody.innerHTML = "<tr><td colspan='4'>No records</td></tr>";
    if (searchCount) searchCount.textContent = "";
    return;
  }
  rows.forEach(r => {
    const name = displayName(r);
    tableBody.innerHTML += `
  <tr id="row-${r.id}">
    <td>${name}</td>
    <td>${r.category}</td>
    <td>${r.onboarding_status}</td>
    <td>
      <div style="display: flex; gap: 8px;">
        <button onclick="viewDetails(${r.id})">
          View Details
        </button>
        <button onclick="downloadAllFiles(${r.id}, '${name.replace(/'/g, "\\'")}')" style="background: #28a745; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer;">
          Download All
        </button>
      </div>
    </td>
  </tr>
`;
  });
}

function filterRows(query) {
  const q = (query || "").toLowerCase().replace(/\s+/g, " ").trim();
  if (!q) {
    renderRows(currentRows);
    if (searchCount) searchCount.textContent = "";
    return;
  }
  const tokens = q.split(" ");
  const filtered = currentRows.filter(r => {
    const name = displayName(r).toLowerCase();
    return tokens.every(t => name.includes(t));
  });
  renderRows(filtered);
  if (searchCount) searchCount.textContent = `${filtered.length} match${filtered.length===1?"":"es"}`;
}

if (location.pathname.includes("admin-list")) {
  const currentStatus = new URLSearchParams(location.search).get("status");
  fetch(`${API}/registrations/${currentStatus}`)
    .then(r => r.json())
    .then(d => {
      currentRows = d && d.success && Array.isArray(d.data) ? d.data : [];
      renderRows(currentRows);
    });
  if (searchInput) {
    if (searchBtn) {
      searchBtn.addEventListener("click", () => filterRows(searchInput.value));
    }
    searchInput.addEventListener("input", () => filterRows(searchInput.value));
    searchInput.addEventListener("keydown", e => {
      if (e.key === "Enter") filterRows(searchInput.value);
    });
  }
}
function updateRegistrationStatus(registrationId, status, btn) {
  if (!confirm(`Are you sure you want to mark this as ${status}?`)) return;

  fetch(`${API}/registration/${registrationId}/status`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status })
  })
    .then(r => r.json())
    .then(d => {
      if (!d.success) {
        alert("Failed to update status");
        return;
      }
      // 🔆 Visual feedback: only clicked button glows
      const cell = btn.parentElement;
      cell.querySelector(".approve-btn").classList.remove("approved");
      cell.querySelector(".reject-btn").classList.remove("rejected");
      if (status === "Approved") {
        cell.querySelector(".approve-btn").classList.add("approved");
      } else if (status === "Rejected") {
        cell.querySelector(".reject-btn").classList.add("rejected");
      }
      // Remove row from current list (moves to Completed view)
      const row = document.getElementById(`row-${registrationId}`);
      if (row) row.remove();
    })
    .catch(err => console.error("Status update error:", err));
}
function moveToCompleted(registrationId, action) {
  const btnSelector = action === "Approved" ? ".approve-btn" : ".reject-btn";
  const btn = document.querySelector(`#row-${registrationId} ${btnSelector}`);
  updateRegistrationStatus(registrationId, action, btn);
}


function viewDetails(id) {
  location.href = `admin-details.html?registrationId=${id}`;
}

async function downloadAllFiles(registrationId, bankName) {
  try {
    // 1. Fetch registration details to get file metadata
    const res = await fetch(`${API}/registration/${registrationId}`);
    const d = await res.json();
    if (!d.success || !d.data) {
      alert("Failed to fetch registration details");
      return;
    }

    const reg = d.data;
    // Parse files if they are returned as a JSON string
    const files = typeof reg.files === 'string' ? JSON.parse(reg.files) : (reg.files || []);

    if (!files || files.length === 0) {
      alert("No files found for this registration");
      return;
    }

    // 2. Initialize JSZip
    const zip = new JSZip();
    const folderName = bankName.trim() || "Registration_Files";
    const folder = zip.folder(folderName);

    // 3. Download each file and add to ZIP
    // We deduplicate by file_type just like in the details view
    const seenTypes = new Set();
    const downloadPromises = files.map(async (f) => {
      if (!f || !f.id || !f.file_type) return;
      if (seenTypes.has(f.file_type)) return;
      seenTypes.add(f.file_type);

      try {
        const fileRes = await fetch(`${API}/file/view/${f.id}`);
        if (!fileRes.ok) throw new Error(`Failed to fetch file ${f.id}`);
        
        const blob = await fileRes.blob();
        
        // Determine filename: Use file_type but clean it up
        // User example: "rbi files" -> "rbi_files"
        let cleanName = f.file_type.toLowerCase().replace(/ /g, '_');
        
        // Map specific ones if they don't match exactly
        if (cleanName === 'rbi_certificate') cleanName = 'rbi_files';
        if (cleanName === 'gst_certificate') cleanName = 'gst_files';
        if (cleanName === 'fiu_screenshot') cleanName = 'fiu_files';
        if (cleanName === 'nodal_officer_sheet') cleanName = 'nodal_officer_sheet';
        if (cleanName === 'terms_conditions') cleanName = 'terms_conditions';
        
        // Get extension from original file_name if available
        const extMatch = f.file_name ? f.file_name.match(/\.[^.]+$/) : null;
        const extension = extMatch ? extMatch[0] : "";
        
        folder.file(`${cleanName}${extension}`, blob);
      } catch (err) {
        console.error(`Error downloading file ${f.id}:`, err);
      }
    });

    // Wait for all downloads to finish
    await Promise.all(downloadPromises);

    // 4. Generate and trigger ZIP download
    const zipContent = await zip.generateAsync({ type: "blob" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(zipContent);
    link.download = `${folderName}.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);

  } catch (err) {
    console.error("Download All error:", err);
    alert("An error occurred while preparing the download.");
  }
}
