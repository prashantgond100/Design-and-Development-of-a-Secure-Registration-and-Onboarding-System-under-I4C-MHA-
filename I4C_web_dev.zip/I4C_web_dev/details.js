const regId = new URLSearchParams(window.location.search)
  .get("registrationId");

fetch(`http://127.0.0.1:5000/api/admin/registration/${regId}`)
  .then(res => res.json())
  .then(result => {
    if (!result.success || !result.data) {
      console.error("Failed to fetch registration data");
      return;
    }

    const d = result.data;

    // Parse form_data if it's a string
    let form = {};
    try {
      form = typeof d.form_data === "string"
        ? JSON.parse(d.form_data)
        : d.form_data || {};
    } catch (e) {
      console.error("form_data parse error:", e);
    }

    // Parse files if it's a string
    let files = [];
    try {
      files = typeof d.files === "string"
        ? JSON.parse(d.files)
        : Array.isArray(d.files) ? d.files : [];
    } catch (e) {
      console.error("files parse error:", e);
    }

    // LEFT SIDE
    document.getElementById("username").innerText = d.username || "-";
    document.getElementById("category").innerText = d.category || "-";

    document.getElementById("email").innerText = form.official_email || "-";
    document.getElementById("contact").innerText = form.contact_number || "-";

    // RIGHT SIDE (FILES)
    const filesDiv = document.getElementById("files");
    filesDiv.innerHTML = "";

    if (!files || files.length === 0) {
      filesDiv.innerHTML = "<p>No files uploaded</p>";
      return;
    }

    files.forEach(f => {
      if (!f) return;
      const div = document.createElement("div");
      div.innerHTML = `
        ${f.file_type || "Unknown File"}
        <button onclick="openFile(${f.id})">View</button>
      `;
      filesDiv.appendChild(div);
    });
  })
  .catch(err => {
    console.error("Error fetching registration:", err);
  });

function openFile(fileId) {
  window.open(
    `http://127.0.0.1:5000/api/admin/file/view/${fileId}`,
    "_blank"
  );
}
